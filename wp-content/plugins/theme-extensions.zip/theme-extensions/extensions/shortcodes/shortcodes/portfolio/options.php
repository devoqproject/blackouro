<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array (
	'orderby'        => array (
		'label'   => esc_html__( 'Order by', 'oildrop' ),
		'desc'    => esc_html__( 'Choose the order by', 'oildrop' ),
		'type'    => 'select',
		'choices' => array (
			'rand'     => esc_html__( 'Random order', 'oildrop' ),
			'ID'       => esc_html__( 'Order by post id', 'oildrop' ),
			'author'   => esc_html__( 'Order by author', 'oildrop' ),
			'title'    => esc_html__( 'Order by title', 'oildrop' ),
			'date'     => esc_html__( 'Order by date', 'oildrop' ),
			'modified' => esc_html__( 'Order by last modified date', 'oildrop' ),
			'parent'   => esc_html__( 'Order by post/page parent id', 'oildrop' ),
			'none'     => esc_html__( 'No order', 'oildrop' ),
		)
	),
	'order'          => array (
		'label'   => esc_html__( 'Order', 'oildrop' ),
		'desc'    => esc_html__( 'Choose the order', 'oildrop' ),
		'type'    => 'select',
		'choices' => array (
			'DESC' => esc_html__( 'DESC', 'oildrop' ),
			'ASC'  => esc_html__( 'ASC', 'oildrop' ),
		)
	),
	'posts_per_page' => array (
		'label' => esc_html__( 'Posts', 'oildrop' ),
		'desc'  => esc_html__( 'Shoose how many post to list', 'oildrop' ),
		'type'  => 'text',
		'value' => 8
	),
	'columns'        => array (
		'label'   => esc_html__( 'Columns', 'oildrop' ),
		'desc'    => esc_html__( 'Choose columns', 'oildrop' ),
		'type'    => 'select',
		'choices' => array (
			'2' => esc_html__( '2', 'oildrop' ),
			'3' => esc_html__( '3', 'oildrop' ),
			'4' => esc_html__( '4', 'oildrop' ),
		)
	),
	'gallery'        => array (
		'label'   => esc_html__( 'Gallery Style', 'oildrop' ),
		'type'    => 'select',
		'choices' => array (
			'regular'   => esc_html__( 'Gallery Regular', 'oildrop' ),
			'alternate' => esc_html__( 'Gallery Alternate', 'oildrop' ),
			'extended'  => esc_html__( 'Gallery Extended', 'oildrop' ),
		)
	),
	'space'          => array (
		'label' => esc_html__( 'Use Space between ', 'oildrop' ),
		'type'  => 'switch',
	),
	'filter'         => array (
		'label' => esc_html__( 'Hide Categories ', 'oildrop' ),
		'type'  => 'switch',
	),
);