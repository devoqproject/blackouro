<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * @var $number
 * @var $before_widget
 * @var $after_widget
 * @var $title
 * @var $tweets
 */

echo wp_kses_post( $before_widget );
echo wp_kses_post( $title );
?>
    <div class="wrap-twitter">
        <ul>
			<?php
			foreach ( $tweets as $tweet ) {
				$time      = strtotime( $tweet->created_at ); //Sun Nov 13 16:33:26 +0000 2016
				$newformat = date( 'Y/m/d H:i:s', $time );
				echo '<li>';
				echo wp_kses_post( $tweet->text );
				echo '<span><i class="fa fa-twitter"></i>' . $newformat . '</span>';
				echo '</li>';
			}
			?>
        </ul>
    </div>
<?php echo wp_kses_post( $after_widget ); ?>