<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
/* <?php echo esc_attr( $atts['iconboxes_columns_padding'] ); ?> */

/**
 * Animation CSS Classes
 */

$class = '';
$class .= ( ! empty( $atts['iconboxes_column_animation'] ) && $atts['iconboxes_column_animation'] ) ? ' to_animate' : '';
$data_animation = ( ! empty( $atts['iconboxes_column_animation'] ) && $atts['iconboxes_column_animation'] ) ? 'data-animation="' . esc_attr( $atts['iconboxes_column_animation'] ) . '"' : '';

?>
<div class="row iconboxes-row <?php echo esc_attr( $atts[ 'iconboxes_type' ] ); ?>">
	<?php foreach ( $atts[ 'iconboxes' ] as $iconbox ): ?>
        <div class="<?php echo esc_attr( $atts[ 'iconboxes_columns_width' ] ); ?> <?php echo esc_attr( $class ); ?>" <?php echo wp_kses_post( $data_animation ); ?>>
			<?php
			//get icon box shortcode to render iconboxes inside a row
			echo fw_ext( 'shortcodes' )->get_shortcode( 'icon_box' )->render( $iconbox );
			?>
        </div><!-- .icon box -->
	<?php endforeach; //progress_iconbox ?>
</div><!-- .iconboxes-row -->