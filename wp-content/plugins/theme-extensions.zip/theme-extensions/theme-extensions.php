<?php
/*
Plugin Name: Theme Extensions
Description: Additional extensions for OilDrop theme - widgets, post views etc.
Version:     1.1
Author:      mwtemplates
Author URI:  https://themeforest.net/user/mwtemplates/
License:     GPLv2 or later
*/

$plugin_path = plugin_dir_path(__FILE__ );

// Functions
if( get_template() !== 'oildrop' ) {
	include_once( $plugin_path . 'functions.php' );
	add_action( 'wp_enqueue_scripts', 'oildrop_load_theme_extension_assets' );
}

if( ! function_exists( 'oildrop_load_theme_extension_assets' ) ) :
	function oildrop_load_theme_extension_assets() {
		// Load Owl Carousel stylesheet.
		wp_enqueue_style( 'owl-carousel', plugin_dir_url(__FILE__) . 'assets/css/owl.carousel.css' );
		// Load Owl Carousel script.
		wp_enqueue_script( 'owl-carousel', plugin_dir_url(__FILE__) . 'assets/js/owl.carousel.js', array(), "all", true );
	}
endif;

add_action( 'after_setup_theme', 'oildrop_extensions_after_setup_theme_init' );

if( ! function_exists( 'oildrop_extensions_after_setup_theme_init' ) ) :
	function oildrop_extensions_after_setup_theme_init() {

		$plugin_path = plugin_dir_path(__FILE__ );

		// Theme Widgets
		include_once( $plugin_path . 'widgets/widget-banner-strip/widget-banner-strip.php' );
		include_once( $plugin_path . 'widgets/widget-calendar/widget-calendar.php' );
		include_once( $plugin_path . 'widgets/widget-contacts-table/widget-contacts-table.php' );
		include_once( $plugin_path . 'widgets/widget-custom-menu/widget-custom-menu.php' );
		include_once( $plugin_path . 'widgets/widget-recent-comments/widget-recent-comments.php' );
		include_once( $plugin_path . 'widgets/widget-recent-posts/widget-recent-posts.php' );
		include_once( $plugin_path . 'widgets/widget-recent-posts-carousel/widget-recent-posts-carousel.php' );
		include_once( $plugin_path . 'widgets/widget-recent-posts-slider/widget-recent-posts-slider.php' );
		include_once( $plugin_path . 'widgets/widget-recent-projects/widget-recent-projects.php' );
		include_once( $plugin_path . 'widgets/widget-recent-projects-carousel/widget-recent-projects-carousel.php' );
		include_once( $plugin_path . 'widgets/widget-working-hours/widget-working-hours.php' );

		include_once( $plugin_path . 'widgets/widget-services-row/widget-services-row.php' );

		include_once( $plugin_path . 'widgets/widget-unyson-blog-tabs/widget-unyson-blog-tabs.php' );
		include_once( $plugin_path . 'widgets/widget-unyson-facebook/widget-unyson-facebook.php' );
		include_once( $plugin_path . 'widgets/widget-unyson-flickr/widget-unyson-flickr.php' );
		include_once( $plugin_path . 'widgets/widget-unyson-social/widget-unyson-social.php' );
		include_once( $plugin_path . 'widgets/widget-unyson-twitter/widget-unyson-twitter.php' );

		//Theme Mods
		include_once( $plugin_path . 'mods/mod-post-share/mod-post-share.php' );
		include_once( $plugin_path . 'mods/mod-post-likes/mod-post-likes.php' );
		include_once( $plugin_path . 'mods/mod-metabox/mod-metabox.php' );

	}
endif;

//shortcodes to plugin
if ( ! function_exists( 'oildrop_filter_mwt_unyson_additional_shortcodes' ) ) :
	/**
	 * @internal
	 */
	function oildrop_filter_mwt_unyson_additional_shortcodes($locations) {
		$locations[ dirname(__FILE__) . '/extensions' ]
			=
			plugin_dir_url( __FILE__ ) . 'extensions';

		return $locations;
	}
endif; //oildrop_filter_mwt_unyson_additional_shortcodes
add_filter('fw_extensions_locations', 'oildrop_filter_mwt_unyson_additional_shortcodes');
