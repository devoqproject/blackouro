<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array (
	'title' => array (
		'type'  => 'text',
		'label' => esc_html__( 'Skill Title', 'oildrop' ),
		'desc'  => esc_html__( 'Write the skill title content', 'oildrop' ),
		'value' => esc_html__( 'Skill Title', 'oildrop' ),
	),
	'level' => array (
		'type'  => 'text',
		'label' => esc_html__( 'Skill Level', 'oildrop' ),
		'desc'  => esc_html__( 'Write the skill level (0-100)', 'oildrop' ),
		'value' => '50',
	),
);
