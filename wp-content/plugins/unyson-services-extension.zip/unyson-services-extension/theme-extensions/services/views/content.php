<?php
/**
 * @var string $the_content
 */

echo $the_content;
?>