<?php
/**
 * Theme meta boxes
 */

/* Post Additional Short Description Field */

/**
 * Display the metabox
 */

if ( ! function_exists( 'oildrop_shortdesc_custom_metabox' ) ):
	function oildrop_shortdesc_custom_metabox() {
		global $post;
		$shortdesc = get_post_meta( $post->ID, 'shortdesc', true ); ?>

        <label class="screen-reader-text" for="shortdesc"><?php esc_html_e( 'Description:', 'oildrop' ); ?></label>
        <textarea id="shortdesc" name="shortdesc" cols="40" rows="4"><?php if ( $shortdesc ) {
				echo esc_textarea( $shortdesc );
			} ?></textarea>
		<?php
	}
endif;

/**
 * Process the custom metabox fields
 */

if ( ! function_exists( 'oildrop_save_custom_shortdesc' ) ):
	// Add action hooks. Without these we are lost
	add_action( 'save_post', 'oildrop_save_custom_shortdesc' );
	function oildrop_save_custom_shortdesc( $post_id ) {
		global $post;

		if ( ! empty( $_POST[ 'shortdesc' ] ) ) {
			update_post_meta( $post->ID, 'shortdesc', trim( $_POST[ 'shortdesc' ] ) );
		}
	}
endif;

/**
 * Add meta box
 */

if ( ! function_exists( 'oildrop_add_custom_metabox' ) ):
	// Add action hooks. Without these we are lost
	add_action( 'admin_init', 'oildrop_add_custom_metabox' );
	function oildrop_add_custom_metabox() {
		add_meta_box( 'custom-metabox', esc_html__( 'Short Description', 'oildrop' ), 'oildrop_shortdesc_custom_metabox', 'post', 'normal', 'high' );
		add_meta_box( 'custom-metabox', esc_html__( 'Short Description', 'oildrop' ), 'oildrop_shortdesc_custom_metabox', 'page', 'normal', 'default' );
		add_meta_box( 'custom-metabox', esc_html__( 'Short Description', 'oildrop' ), 'oildrop_shortdesc_custom_metabox', 'product', 'normal', 'default' );
		add_meta_box( 'custom-metabox', esc_html__( 'Short Description', 'oildrop' ), 'oildrop_shortdesc_custom_metabox', 'team_member', 'normal', 'default' );
		add_meta_box( 'custom-metabox', esc_html__( 'Short Description', 'oildrop' ), 'oildrop_shortdesc_custom_metabox', 'fw-portfolio', 'normal', 'default' );
		add_meta_box( 'custom-metabox', esc_html__( 'Short Description', 'oildrop' ), 'oildrop_shortdesc_custom_metabox', 'fw-services', 'normal', 'default' );
	}
endif;

/**
 * Get and return the values for the short description
 */

if ( ! function_exists( 'oildrop_get_custom_shortdesc_box' ) ):
	function oildrop_get_custom_shortdesc_box( $id = null ) {
		if ( $id == null ) {
			global $post;
			$id = $post->ID;
		}
		$shortdesc = get_post_meta( $id, 'shortdesc', true );

		return array ( $shortdesc );
	}
endif;

/* End */
