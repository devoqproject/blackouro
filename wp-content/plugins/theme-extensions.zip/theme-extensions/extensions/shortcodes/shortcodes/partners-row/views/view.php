<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$class = '';
/**
 * Animation CSS Classes
 */

$class .= ( ! empty( $atts['partners_column_animation'] ) && $atts['partners_column_animation'] ) ? ' to_animate' : '';
$data_animation = ( ! empty( $atts['partners_column_animation'] ) && $atts['partners_column_animation'] ) ? 'data-animation="' . esc_attr( $atts['partners_column_animation'] ) . '"' : '';

?>
<div class="row partners-row <?php echo esc_attr( $atts[ 'partners_type' ] ); ?>">
	<?php foreach ( $atts[ 'partners' ] as $partner ): ?>
        <div class="<?php echo esc_attr( $atts[ 'partners_columns_width' ] ); ?> <?php echo esc_attr( $class ); ?>" <?php echo wp_kses_post( $data_animation ); ?>>
			<?php
			//get partner shortcode to render partners inside a row
			echo fw_ext( 'shortcodes' )->get_shortcode( 'partner' )->render( $partner );
			?>
        </div><!-- .partner -->
	<?php endforeach; //progress_partner ?>
</div> <!-- .partners-row -->