<?php
/*
Plugin Name: Modern Web Templates theme addons
Description: Additional functions for mwtemplates theme
Version:     1.0.2
Author:      mwtemplates
Author URI:  https://themeforest.net/user/mwtemplates/
License:     GPLv2 or later
*/

require_once  plugin_dir_path( __FILE__ ) . '/mwt-misc.php';
