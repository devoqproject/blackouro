<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array (
	'page_builder' => array (
		'title'       => esc_html__( 'Partners in Row', 'oildrop' ),
		'description' => esc_html__( 'Several partners in row', 'oildrop' ),
		'tab'         => esc_html__( 'Content Elements', 'oildrop' ),
	)
);