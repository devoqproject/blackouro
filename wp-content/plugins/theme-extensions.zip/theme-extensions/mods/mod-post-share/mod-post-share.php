<?php

if ( ! function_exists( 'oildrop_share_this' ) ) :
	/**
	 * Share article through social networks.
	 */
	function oildrop_share_this( $heading = '' ) {
		if ( empty( $heading ) ) {
			$heading = esc_html__( '', 'oildrop' );
		}
		?>
		<div class="share-this">
			<?php if ( $heading !== '' ): ?>
				<div class="share-this-divider">
					<?php echo esc_attr( $heading ); ?>
				</div>
			<?php endif; ?>
			<ul class="share-icons">
				<!-- twitter -->
				<li>
					<a href="https://twitter.com/share?text=<?php echo esc_attr( urlencode( get_the_title() ) ); ?>&amp;url=<?php echo esc_url( get_permalink() ); ?>"
					   onclick="window.open(this.href, 'twitter-share', 'width=550,height=235');return false;"><i
							class="fa fa-twitter"></i></a>
				</li>
				<!-- facebook -->
				<li>
					<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url( get_permalink() ); ?>"
					   onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;"><i
							class="fa fa-facebook"></i></a>
				</li>
				<!-- google plus -->
				<li>
					<a href="https://plus.google.com/share?url=<?php echo esc_url( get_permalink() ); ?>"
					   onclick="window.open(this.href, 'google-plus-share', 'width=490,height=530');return false;"><i
							class="fa fa-google-plus"></i></a>
				</li>
				<!-- pinterest -->
				<li>
					<a href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','http://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"><i
							class="fa fa-pinterest"></i></a>
				</li>
				<!-- linkedin -->
				<li>
					<a href="https://www.linkedin.com/shareArticle?mini=true%26url=<?php echo esc_url( get_permalink() ); ?>%26source="
					   onclick="window.open(this.href, 'linkedin-share', 'width=490,height=530');return false;"><i
							class="fa fa-linkedin"></i></a>
				</li>
			</ul>
		</div>
		<?php
	}
endif;
