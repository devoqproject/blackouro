<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
// Check if Portfolio extension is on
if ( fw_ext( 'portfolio' ) ) {
	$shortcodes_extension = fw_ext( 'shortcodes' );

	$ext_instance = fw()->extensions->get( 'portfolio' );

	fw_include_file_isolated( $ext_instance->get_path( '/static.php' ) );

	if ( ! is_admin() ) {

		$settings = $ext_instance->get_settings();

		if ( ! empty( $settings ) ) {

			//

		}
	}

} //if ( fw_ext('portfolio') )