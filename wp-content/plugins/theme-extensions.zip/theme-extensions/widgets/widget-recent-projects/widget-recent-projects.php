<?php
/**
 * Recent_Projects [Unyson] widget class.0
 */

if ( defined( 'FW' ) ) {

class OILDROP_Widget_Recent_Projects extends WP_Widget {

	public function __construct() {
		$widget_ops = array('classname' => 'widget_recent_projects', 'description' => esc_html__( "Display News as Gallery Strip", 'oildrop') );
		parent::__construct('recent-projects', esc_html__('Recent Projects', 'oildrop'), $widget_ops);
		$this->alt_option_name = 'widget_recent_projects';
	}

	public function widget($args, $instance) {

		ob_start();

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$big_image = isset( $instance['big_image'] ) ? absint( $instance['big_image'] ) : 1;
		if ( $big_image == 1 ) {
			$posts_num = 10;
		} else {
		    $posts_num = 18;
		}

		/**
		 * Filter the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 */
		$r = new WP_Query( apply_filters( 'widget_posts_args', array(
			'posts_per_page'      => $posts_num,
			'no_found_rows'       => true,
			'post_type'           => 'fw-portfolio',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
		) ) );

		if ($r->have_posts()) :
		$thumbnail_args = array(
            'background' => true,
            'print' => true,
            'thumbnail_size' => 'oildrop_top-news-3-2',
            'thumbnail_class' => 'oildrop_top-news-3-2',
            'use_default' => true,
            'is_widget' => true,
        );
			?>
			<?php

			// Check if Portfolio extension is on
		    if ( fw_ext('portfolio') ) {

			?>
			<?php echo wp_kses_post($args['before_widget']); ?>
			<?php if ( $title ) {
			    echo wp_kses_post($args['before_title'] . $title . $args['after_title']);
		    } ?>
			<div class="row <?php echo 'big-image-' . esc_attr($big_image); ?>">
			<?php
			$i = 0;
			while ( $r->have_posts() ) : $r->the_post();

                if( $big_image == 1 ) {
                    if ( !$i ) {
                        ?>
                        <div class="col-md-6 <?php echo 'row-' . $i; ?>">
                            <div class="recent-projects-item-content recent-projects-high"
                                 style="<?php oildrop_post_thumbnail($thumbnail_args) ?>">
                                <div class="recent-projects-item-content--table">
                                    <div class="recent-projects-item-content--cell">
                                        <div class="overlay"></div>
                                        <a class="recent-projects-link" href="<?php the_permalink(); ?>"></a>
                                        <div class="recent-projects-item-meta">
                                            <h2 class="recent-projects-title">
                                                <a href="<?php the_permalink(); ?>"><?php get_the_title() ? the_title() : the_ID(); ?></a>
                                            </h2>
                                        </div>
                                        <br class="clear">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }

                    if( $i == 1 ){
                        echo '<div class="col-md-6 row-' . $i . '"><div class="row row-' . $i . '">';
                    }

                    // Post thumbnail.
                    if( $i > 0 ) {
                        ?>
                        <div class="col-sm-4 col-xs-4 <?php echo 'row-item-' . $i; ?>">
                            <div class="recent-projects-item">
                                <div class="recent-projects-item-content recent-projects-low" style="<?php oildrop_post_thumbnail($thumbnail_args) ?>">
                                    <div class="overlay"></div>
                                    <a class="recent-projects-link" href="<?php the_permalink(); ?>"></a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }

                    if( $i && !($i % 3) && $i != ( $posts_num - 1 ) ){
                        echo '</div><div class="row row-' . $i . '">';
                    } elseif( $i && !($i % 3) && $i == ( $posts_num - 1 ) ) {
                        echo '</div>';
                    }
                } else {
                    if ( $i && !( $i % 6 ) ) {
                        echo '<div class="row big-image-2 row-' . $i . '">';
                    }

                    if(!( $i % 3 ) ){
                        echo '<div class="col-md-6 row-' . $i . '"><div class="row row-' . $i . '">';
                    }

                    // Post thumbnail.
                    ?>
                    <div class="col-sm-4 col-xs-4 <?php echo 'row-item-' . $i; ?>">
                        <div class="recent-projects-item">
                            <div class="recent-projects-item-content recent-projects-low" style="<?php oildrop_post_thumbnail($thumbnail_args) ?>">
                                <div class="overlay"></div>
                                <a class="recent-projects-link" href="<?php the_permalink(); ?>"></a>
                            </div>
                        </div>
                    </div>
                    <?php

                    if( $i && !( ($i + 1) % 3 ) ){
                        echo '</div></div>'; // </row></col-md-6>
                    }

                    if( $i && !( ($i + 1) % 6 ) ){
                        echo '</div>'; // </row>
                    }
                }

				$i++;

			endwhile;

            if( $big_image == 1 ) {
                if ($i && !($i % 3) && $i < $posts_num) {
                    echo '</div>';
                }

                if ($i > 0) {
                    echo '</div>';
                }

                echo '</div>';
            } else {
                if ($i && !(($i - 1) % 3) && $i < $posts_num) {
                    echo '</div></div>';//</row></col-md-6>
                }

                if ( $i && ($i % 6) && $i < $posts_num ) {
                    echo '</div>';// </row>
                }
            }
			?>
			<?php echo wp_kses_post($args['after_widget']); ?>
			<?php
			// Reset the global $the_post as this query will have stomped on it
			wp_reset_postdata();

			} //if ( fw_ext('portfolio') )

		endif;

		ob_end_flush();
		
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['big_image'] = (int) $new_instance['big_image'];

		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['widget_recent_projects']) )
			{delete_option('widget_recent_projects');}

		return $instance;
	}

	public function form( $instance ) {
	    $title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$big_image    = isset( $instance['big_image'] ) ? absint( $instance['big_image'] ) : 1;
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo wp_kses( __( 'Title', 'oildrop' ), $allowed_html_array = array( 'br' => array(), 'i' => array() ) ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<strong><?php esc_html_e( 'Layout:', 'oildrop' ); ?></strong><br>
			<label for="<?php echo esc_attr( $this->get_field_id( 'left' ) ); ?>" class="recent-projects-radio-label">
				<input class="recent-projects-radio" type="radio" <?php checked( $big_image == 1 ); ?> id="<?php echo esc_attr( $this->get_field_id( 'left' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'big_image' ) ); ?>" value="1" />
				<img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/recent-projects-left.gif'; ?>" alt="<?php echo esc_attr__('Left', 'oildrop'); ?>">
			</label>
			<label for="<?php echo esc_attr( $this->get_field_id( 'none' ) ); ?>" class="recent-projects-radio-label">
				<input class="recent-projects-radio" type="radio" <?php checked( $big_image == 2 ); ?> id="<?php echo esc_attr( $this->get_field_id( 'none' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'big_image' ) ); ?>" value="2" />
				<img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/recent-projects-none.gif'; ?>" alt="<?php echo esc_attr__('None', 'oildrop'); ?>">
			</label>
		</p>

		<?php
	}
}

if ( ! function_exists( 'oildrop_recent_projects_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
     * Add a comment to this line
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function oildrop_recent_projects_setup() {
        if(!has_image_size('oildrop_top-news-3-2')){
		    add_image_size('oildrop_top-news-3-2', 640, 427, true);
		}
	}
endif; // oildrop_top_news_setup
add_action( 'after_setup_theme', 'oildrop_recent_projects_setup', 20 );

if ( ! function_exists( 'oildrop_register_widget_recent_projects' ) ) :
	function oildrop_register_widget_recent_projects() {
		register_widget( 'OILDROP_Widget_Recent_Projects' );
	}
endif;
add_action( 'widgets_init', 'oildrop_register_widget_recent_projects' );
// Style and script included in main files

}// if ( defined( 'FW' ) ) {}