<?php

/**
 * Calendar widget class.0
 */
class OILDROP_Widget_Calendar extends WP_Widget_Calendar {

	public function __construct() {
		$widget_ops = array ( 'classname'   => 'widget_calendar',
		                      'description' => esc_html__( 'A calendar of your site&#8217;s Posts.', 'oildrop' )
		);
		parent::__construct( 'oildrop_calendar', esc_html__( 'Calendar', 'oildrop' ), $widget_ops );
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', empty( $instance[ 'title' ] ) ? '' : $instance[ 'title' ], $instance, $this->id_base );

		echo wp_kses_post( $args[ 'before_widget' ] );
		if ( $title ) {
			echo wp_kses_post( $args[ 'before_title' ] . $title . $args[ 'after_title' ] );
		}
		echo '<div id="calendar_wrap">';
		oildrop_get_calendar();
		echo '</div>';
		echo wp_kses_post( $args[ 'after_widget' ] );
	}

	/**
	 * @param array $new_instance
	 * @param array $old_instance
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$instance            = $old_instance;
		$instance[ 'title' ] = strip_tags( $new_instance[ 'title' ] );

		return $instance;
	}

	/**
	 * @param array $instance
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array ( 'title' => '' ) );
		$title    = strip_tags( $instance[ 'title' ] );
		?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'oildrop' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
                   value="<?php echo esc_attr( $title ); ?>"/></p>
		<?php
	}

}

if ( ! function_exists( 'oildrop_register_widget_calendar' ) ) :
	function oildrop_register_widget_calendar() {
		if ( ! is_active_widget( false, false, 'monster' ) ) {
			unregister_widget( 'WP_Widget_Calendar' );
		}
		register_widget( 'OILDROP_Widget_Calendar' );
	}
endif;
add_action( 'widgets_init', 'oildrop_register_widget_calendar' );

/**
 * Display calendar with days that have posts as links.
 *
 * The calendar is cached, which will be retrieved, if it exists. If there are
 * no posts for the month, then it will not be displayed.
 *
 * @since 1.0.0
 *
 * @global wpdb $wpdb
 * @global int $m
 * @global int $monthnum
 * @global int $year
 * @global WP_Locale $wp_locale
 * @global array $posts
 *
 * @param bool $initial Optional, default is true. Use initial calendar names.
 * @param bool $echo Optional, default is true. Set to false for return.
 *
 * @return string|void String when retrieving.
 */
function oildrop_get_calendar( $initial = true, $echo = true ) {
	global $wpdb, $m, $monthnum, $year, $wp_locale, $posts;

	$key = md5( $m . $monthnum . $year );
	if ( $cache = wp_cache_get( 'get_calendar', 'oildrop_calendar' ) ) {
		if ( is_array( $cache ) && isset( $cache[ $key ] ) ) {
			if ( $echo ) {
				/** This filter is documented in wp-includes/general-template.php */
				echo apply_filters( 'get_calendar', $cache[ $key ] );

				return;
			} else {
				/** This filter is documented in wp-includes/general-template.php */
				return apply_filters( 'get_calendar', $cache[ $key ] );
			}
		}
	}

	if ( ! is_array( $cache ) ) {
		$cache = array ();
	}

	// Quick check. If we have no posts at all, abort!
	if ( ! $posts ) {
		$gotsome = $wpdb->get_var( $wpdb->prepare( "SELECT 1 as test FROM %s WHERE post_type = 'post' AND post_status = 'publish' LIMIT 1", $wpdb->posts ) );
		if ( ! $gotsome ) {
			$cache[ $key ] = '';
			wp_cache_set( 'get_calendar', $cache, 'oildrop_calendar' );

			return;
		}
	}

	if ( isset( $_GET[ 'w' ] ) ) {
		$w = '' . intval( $_GET[ 'w' ] );
	}

	// week_begins = 0 stands for Sunday
	$week_begins = intval( get_option( 'start_of_week' ) );

	// Let's figure out when we are
	if ( ! empty( $monthnum ) && ! empty( $year ) ) {
		$thismonth = '' . zeroise( intval( $monthnum ), 2 );
		$thisyear  = '' . intval( $year );
	} elseif ( ! empty( $w ) ) {
		// We need to get the month from MySQL
		$thisyear  = '' . intval( substr( $m, 0, 4 ) );
		$d         = ( ( $w - 1 ) * 7 ) + 6; //it seems MySQL's weeks disagree with PHP's
		$thismonth = $wpdb->get_var( $wpdb->prepare( "SELECT DATE_FORMAT((DATE_ADD('{%d}0101', INTERVAL %d DAY) ), '%m')", $thisyear, $d ) );
	} elseif ( ! empty( $m ) ) {
		$thisyear = '' . intval( substr( $m, 0, 4 ) );
		if ( strlen( $m ) < 6 ) {
			$thismonth = '01';
		} else {
			$thismonth = '' . zeroise( intval( substr( $m, 4, 2 ) ), 2 );
		}
	} else {
		$thisyear  = gmdate( 'Y', current_time( 'timestamp' ) );
		$thismonth = gmdate( 'm', current_time( 'timestamp' ) );
	}

	$unixmonth = mktime( 0, 0, 0, $thismonth, 1, $thisyear );
	$last_day  = date( 't', $unixmonth );

	// Get the next and previous month and year with at least one post
	$previous = $wpdb->get_row( $wpdb->prepare( "SELECT MONTH(post_date) AS month, YEAR(post_date) AS year
		FROM $wpdb->posts
		WHERE post_date < '%d-%d-01'
		AND post_type = 'post' AND post_status = 'publish'
			ORDER BY post_date DESC
			LIMIT 1", $thisyear, $thismonth ) );
	$next     = $wpdb->get_row( $wpdb->prepare( "SELECT MONTH(post_date) AS month, YEAR(post_date) AS year
		FROM $wpdb->posts
		WHERE post_date > '%d-%d-{%d} 23:59:59'
		AND post_type = 'post' AND post_status = 'publish'
			ORDER BY post_date ASC
			LIMIT 1", $thisyear, $thismonth, $last_day ) );

	/* translators: Calendar caption: 1: month name, 2: 4-digit year */
	$calendar_caption = esc_html_x( '%1$s %2$s', 'calendar caption', 'oildrop' );
	$calendar_output  = '';
	$calendar_output .= '

	<div class="calendar__navigation">';

	if ( $previous ) {
		$calendar_output .= "\n\t\t" . '<div id="prev"><a href="' . get_month_link( $previous->year, $previous->month ) . '"><i class="rt-icon icon-chevron-thin-left"></i></a></div>';
	} else {
		$calendar_output .= "\n\t\t" . '<div id="prev" class="empty"><span>&nbsp;</span></div>';
	}

	if ( $next ) {
		$calendar_output .= "\n\t\t" . '<div id="next"><a href="' . get_month_link( $next->year, $next->month ) . '"><i class="rt-icon icon-chevron-thin-right"></i></a></div>';
	} else {
		$calendar_output .= "\n\t\t" . '<div id="next" class="empty"><span>&nbsp;</span></div>';
	}

	$calendar_output .= '<div class="calendar__month">' . sprintf( $calendar_caption, $wp_locale->get_month( $thismonth ), date( 'Y', $unixmonth ) ) . '</div>';

	$calendar_output .= '
	</div>

	';

	$calendar_output .= '

	<div class="calendar__week">
	<table>
	<thead>
	<tr>';

	$myweek = array ();

	for ( $wdcount = 0; $wdcount <= 6; $wdcount ++ ) {
		$myweek[] = $wp_locale->get_weekday( ( $wdcount + $week_begins ) % 7 );
	}

	foreach ( $myweek as $wd ) {
		$day_name = substr( $wd, 0, 3 );
		$wd       = esc_attr( $wd );
		$calendar_output .= "\n\t\t<th scope=\"col\" title=\"$wd\">$day_name</th>";
	}

	$calendar_output .= '
	</tr>
	</thead>
	</table>
	</div>';

	$calendar_output .= '<table id="wp-calendar">';

	$calendar_output .= '

	<tbody>
	<tr>';

	$daywithpost = array ();

	// Get days with posts
	$dayswithposts = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT DAYOFMONTH(post_date)
		FROM $wpdb->posts WHERE post_date >= '{%d}-{%d}-01 00:00:00'
		AND post_type = 'post' AND post_status = 'publish'
		AND post_date <= '{%d}-{%d}-{%d} 23:59:59'", $thisyear, $thismonth, $thisyear, $thismonth, $last_day ), ARRAY_N );
	if ( $dayswithposts ) {
		foreach ( (array) $dayswithposts as $daywith ) {
			$daywithpost[] = $daywith[ 0 ];
		}
	}

	$ak_titles_for_day = array ();
	$ak_post_titles    = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, DAYOFMONTH(post_date) as dom "
	                                                         . "FROM $wpdb->posts "
	                                                         . "WHERE post_date >= '{%d}-{%d}-01 00:00:00' "
	                                                         . "AND post_date <= '{%d}-{%d}-{%d} 23:59:59' "
	                                                         . "AND post_type = 'post' AND post_status = 'publish'"
		, $thisyear, $thismonth, $thisyear, $thismonth, $last_day ) );
	if ( $ak_post_titles ) {
		foreach ( (array) $ak_post_titles as $ak_post_title ) {

			/** This filter is documented in wp-includes/post-template.php */
			$post_title = esc_attr( apply_filters( 'the_title', $ak_post_title->post_title, $ak_post_title->ID ) );

			if ( empty( $ak_titles_for_day[ 'day_' . $ak_post_title->dom ] ) ) {
				$ak_titles_for_day[ 'day_' . $ak_post_title->dom ] = '';
			}
			if ( empty( $ak_titles_for_day[ "$ak_post_title->dom" ] ) ) // first one
			{
				$ak_titles_for_day[ "$ak_post_title->dom" ] = $post_title;
			} else {
				$ak_titles_for_day[ "$ak_post_title->dom" ] .= $ak_title_separator . $post_title;
			}
		}
	}

	// See how much we should pad in the beginning
	$pad = calendar_week_mod( date( 'w', $unixmonth ) - $week_begins );
	if ( 0 != $pad ) {
		$calendar_output .= "\n\t\t" . '<td colspan="' . esc_attr( $pad ) . '" class="pad">&nbsp;</td>';
	}

	$daysinmonth = intval( date( 't', $unixmonth ) );
	for ( $day = 1; $day <= $daysinmonth; ++ $day ) {
		if ( isset( $newrow ) && $newrow ) {
			$calendar_output .= "\n\t</tr>\n\t<tr>\n\t\t";
		}
		$newrow = false;

		if ( $day == gmdate( 'j', current_time( 'timestamp' ) ) && $thismonth == gmdate( 'm', current_time( 'timestamp' ) ) && $thisyear == gmdate( 'Y', current_time( 'timestamp' ) ) ) {
			$calendar_output .= '<td id="today">';
		} else {
			$calendar_output .= '<td>';
		}

		if ( in_array( $day, $daywithpost ) ) // any posts today?
		{
			$calendar_output .= '<a href="' . get_day_link( $thisyear, $thismonth, $day ) . '" title="' . esc_attr( $ak_titles_for_day[ $day ] ) . "\">$day</a>";
		} else {
			$calendar_output .= $day;
		}
		$calendar_output .= '</td>';

		if ( 6 == calendar_week_mod( date( 'w', mktime( 0, 0, 0, $thismonth, $day, $thisyear ) ) - $week_begins ) ) {
			$newrow = true;
		}
	}

	$pad = 7 - calendar_week_mod( date( 'w', mktime( 0, 0, 0, $thismonth, $day, $thisyear ) ) - $week_begins );
	if ( $pad != 0 && $pad != 7 ) {
		$calendar_output .= "\n\t\t" . '<td class="pad" colspan="' . esc_attr( $pad ) . '">&nbsp;</td>';
	}

	$calendar_output .= "\n\t</tr>\n\t</tbody>\n\t</table>";

	$cache[ $key ] = $calendar_output;
	wp_cache_set( 'get_calendar', $cache, 'oildrop_calendar' );

	if ( $echo ) {
		/**
		 * Filter the HTML calendar output.
		 *
		 * @since 3.0.0
		 *
		 * @param string $calendar_output HTML output of the calendar.
		 */
		echo apply_filters( 'get_calendar', $calendar_output );
	} else {
		/** This filter is documented in wp-includes/general-template.php */
		return apply_filters( 'get_calendar', $calendar_output );
	}

}