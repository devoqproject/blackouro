<?php

/**
 * Recent_Posts_Carousel widget class.0
 */
class OILDROP_widget_recent_projects_carousel extends WP_Widget {

	public function __construct() {
		$widget_ops = array (
			'classname'   => 'widget_recent_projects_carousel',
			'description' => esc_html__( "Your site&#8217;s team members organized in Slider.", 'oildrop' )
		);
		parent::__construct( 'recent-projects-carousel', esc_html__( 'Recent Projects Carousel', 'oildrop' ), $widget_ops );
		$this->alt_option_name = 'widget_recent_projects_carousel';
	}

	public function widget( $args, $instance ) {

		if ( ! isset( $args[ 'widget_id' ] ) ) {
			$args[ 'widget_id' ] = $this->id;
		}
		$unique_id = uniqid();

		ob_start();

		$title = ( ! empty( $instance[ 'title' ] ) ) ? $instance[ 'title' ] : '';

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance[ 'number' ] ) ) ? absint( $instance[ 'number' ] ) : 5;
		if ( ! $number ) {
			$number = 5;
		}
		$category        = isset( $instance[ 'category' ] ) ? $instance[ 'category' ] : '';
		$show_navigation = isset( $instance[ 'show_navigation' ] ) ? $instance[ 'show_navigation' ] : false;
		$autoplay        = isset( $instance[ 'autoplay' ] ) ? $instance[ 'autoplay' ] : false;

		$thumbnail_args = array (
			'thumbnail_size'  => 'oildrop_top-news-3-2',
			'thumbnail_class' => 'oildrop_top-news-3-2',
			'use_default'     => true,
			'is_widget'       => true,
			'no_url'          => true,
		);

		/**
		 * Filter the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 */

		$r = new WP_Query(
			array (
				'post_type'           => 'fw-portfolio',
				'posts_per_page'      => $number,
				'no_found_rows'       => true,
				'post_status'         => 'publish',
				'category_name'       => $category,
				'ignore_sticky_posts' => true,
			)
		);

		if ( $r->have_posts() ) :
			?>
			<?php echo wp_kses_post( $args[ 'before_widget' ] ); ?>
			<?php if ( $title ) {
			echo wp_kses_post( $args[ 'before_title' ] . $title . $args[ 'after_title' ] );
		} ?>

			<?php if ( function_exists( 'cct_get_member_meta' ) ) : ?>

            <div
                    class="owl-recent-projects-carousel owl-recent-projects-carousel<?php echo esc_attr( $unique_id ) ?> owl-carousel rpj-carousel <?php echo esc_attr( $show_navigation ); ?>"
                    data-show_navigation="<?php echo esc_attr( $show_navigation ) ? 'true' : 'false' ?>"
                    data-autoplay="<?php echo esc_attr( $autoplay ) ? 'true' : 'false' ?>"
                    data-unique_id="<?php echo esc_attr( $unique_id ); ?>">
				<?php while ( $r->have_posts() ) : $r->the_post(); ?>
					<?php


					?>
                    <div class="item">
                        <div class="rpj-carousel__image">
                            <a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
								<?php oildrop_post_thumbnail( $thumbnail_args ) ?>
                            </a>
                        </div>
                    </div><!-- .item -->
				<?php endwhile; ?>
            </div>

		<?php endif; ?>

			<?php echo wp_kses_post( $args[ 'after_widget' ] ); ?>
			<?php
			// Reset the global $the_post as this query will have stomped on it
			wp_reset_postdata();

		endif;

		if ( ! $this->is_preview() ) {
			$cache[ $args[ 'widget_id' ] ] = ob_get_flush();
			wp_cache_set( 'widget_recent_projects_carousel', $cache, 'widget' );
		} else {
			ob_end_flush();
		}
	}

	public function update( $new_instance, $old_instance ) {
		$instance                      = $old_instance;
		$instance[ 'title' ]           = strip_tags( $new_instance[ 'title' ] );
		$instance[ 'number' ]          = (int) $new_instance[ 'number' ];
		$instance[ 'category' ]        = $new_instance[ 'category' ];
		$instance[ 'show_navigation' ] = isset( $new_instance[ 'show_navigation' ] ) ? (bool) $new_instance[ 'show_navigation' ] : false;
		$instance[ 'autoplay' ]        = isset( $new_instance[ 'autoplay' ] ) ? (bool) $new_instance[ 'autoplay' ] : false;

		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset( $alloptions[ 'widget_recent_projects_carousel' ] ) ) {
			delete_option( 'widget_recent_projects_carousel' );
		}

		return $instance;
	}

	public function form( $instance ) {
		$title           = isset( $instance[ 'title' ] ) ? esc_attr( $instance[ 'title' ] ) : '';
		$number          = isset( $instance[ 'number' ] ) ? absint( $instance[ 'number' ] ) : 5;
		$category        = isset( $instance[ 'category' ] ) ? $instance[ 'category' ] : '';
		$show_navigation = isset( $instance[ 'show_navigation' ] ) ? (bool) $instance[ 'show_navigation' ] : false;
		$autoplay        = isset( $instance[ 'autoplay' ] ) ? (bool) $instance[ 'autoplay' ] : false;

		?>
        <p>
            <label
                    for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo wp_kses( __( 'Title<br><i>carousel title</i>', 'oildrop' ), $allowed_html_array = array (
					'br' => array (),
					'i'  => array ()
				) ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
                   value="<?php echo esc_attr( $title ); ?>"/>
        </p>

        <p>
            <label
                    for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php echo wp_kses( __( 'Number of posts<br><i>to show</i>', 'oildrop' ), $allowed_html_array = array (
					'br' => array (),
					'i'  => array ()
				) ); ?></label>
            <input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number"
                   value="<?php echo esc_attr( absint( $number ) ); ?>" size="3"/>
        </p>

        <p>
            <input class="checkbox" type="checkbox" <?php checked( $show_navigation ); ?>
                   id="<?php echo esc_attr( $this->get_field_id( 'show_navigation' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'show_navigation' ) ); ?>"/>
            <label
                    for="<?php echo esc_attr( $this->get_field_id( 'show_navigation' ) ); ?>"><?php esc_html_e( 'Show navigation?', 'oildrop' ); ?></label>
        </p>

        <p>
            <input class="checkbox" type="checkbox" <?php checked( $autoplay ); ?>
                   id="<?php echo esc_attr( $this->get_field_id( 'autoplay' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'autoplay' ) ); ?>"/>
            <label
                    for="<?php echo esc_attr( $this->get_field_id( 'autoplay' ) ); ?>"><?php esc_html_e( 'Auto play', 'oildrop' ); ?></label>
        </p>

		<?php
	}
}

if ( ! function_exists( 'oildrop_recent_projects_carousel_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function oildrop_recent_projects_carousel_setup() {
		if ( ! has_image_size( 'oildrop_top-news-3-2' ) ) {
			add_image_size( 'oildrop_top-news-3-2', 770, 513, true );
		}
		if ( ! has_image_size( 'oildrop_top-news-3-3' ) ) {
			add_image_size( 'oildrop_top-news-3-3', 770, 770, true );
		}
	}
endif; // oildrop_top_news_setup
add_action( 'after_setup_theme', 'oildrop_recent_projects_carousel_setup', 20 );

if ( ! function_exists( 'oildrop_register_widget_recent_projects_carousel' ) ) :
	function oildrop_register_widget_recent_projects_carousel() {
		register_widget( 'OILDROP_widget_recent_projects_carousel' );
	}
endif;
add_action( 'widgets_init', 'oildrop_register_widget_recent_projects_carousel' );
// Style and script included in main files