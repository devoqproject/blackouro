<?php

/**
 * Recent_Posts_Carousel widget class.0
 */
class OILDROP_Widget_Services_Row extends WP_Widget {

	public function __construct() {
		$widget_ops = array (
			'classname'   => 'widget_services_row',
			'description' => esc_html__( "Your site&#8217;s services organized in Slider.", 'oildrop' )
		);
		parent::__construct( 'services-row', esc_html__( 'Services Row', 'oildrop' ), $widget_ops );
		$this->alt_option_name = 'widget_services_row';
	}

	public function widget( $args, $instance ) {

		if ( ! isset( $args[ 'widget_id' ] ) ) {
			$args[ 'widget_id' ] = $this->id;
		}

		ob_start();

		$title = ( ! empty( $instance[ 'title' ] ) ) ? $instance[ 'title' ] : '';

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance[ 'number' ] ) ) ? absint( $instance[ 'number' ] ) : 3;
		if ( ! $number ) {
			$number = 3;
		}
		$category = isset( $instance[ 'category' ] ) ? $instance[ 'category' ] : '';

		$thumbnail_args = array (
			'thumbnail_size'  => 'oildrop_top-news-3-3',
			'thumbnail_class' => 'oildrop_top-news-3-3',
			'use_default'     => true,
			'is_widget'       => true,
			'no_url'          => true,
		);

		/**
		 * Filter the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 */

		if ( $category == '' || $category == '0' ) {
			$r = new WP_Query( array (
				'post_type'           => 'fw-services',
				'posts_per_page'      => $number,
				'post_status'         => 'publish',
				'ignore_sticky_posts' => true
			) );
		} else {
			$r = new WP_Query( array (
				'post_type'           => 'fw-services',
				'tax_query'           => array (
					array (
						'taxonomy' => 'fw-services-category',
						'field'    => 'slug',
						'terms'    => $category
					)
				),
				'posts_per_page'      => $number,
				'post_status'         => 'publish',
				'ignore_sticky_posts' => true
			) );
		}

		if ( $r->have_posts() ) :
			?>
			<?php echo wp_kses_post( $args[ 'before_widget' ] ); ?>
			<?php if ( $title ) {
			echo wp_kses_post( $args[ 'before_title' ] . $title . $args[ 'after_title' ] );
		} ?>

			<?php

			$ext_services_instance = fw()->extensions->get( 'services' );
			$ext_services_settings = $ext_services_instance->get_settings();

			$taxonomy   = $ext_services_settings[ 'taxonomy_name' ];
			$term       = get_term_by( 'slug', get_query_var( 'term' ), $taxonomy );
			$term_id    = ( ! empty( $term->term_id ) ) ? $term->term_id : 0;
			$categories = fw_ext_services_get_listing_categories( $term_id );

			$loop_data = array (
				'settings'    => $ext_services_instance->get_settings(),
				'categories'  => $categories,
				'image_sizes' => $ext_services_instance->get_image_sizes(),
			);
			set_query_var( 'fw_services_loop_data', $loop_data );

			?>

            <div class="services-row">
                <ul id="services-list" class="services-list services-list--items-<?php echo esc_attr( $number ); ?>">
					<?php while ( $r->have_posts() ) : $r->the_post(); ?>

						<?php

						$loop_data = get_query_var( 'fw_services_loop_data' );

						$thumbnails_params     = $loop_data[ 'image_sizes' ][ 'featured-image' ];
						$thumbnails_params_big = $loop_data[ 'image_sizes' ][ 'gallery-image' ];

						$thumbnail_id = get_post_thumbnail_id();
						if ( ! empty( $thumbnail_id ) ) {
							$thumbnail       = get_post( $thumbnail_id );
							$image           = fw_resize( $thumbnail->ID, $thumbnails_params[ 'width' ], $thumbnails_params[ 'height' ], $thumbnails_params[ 'crop' ] );
							$image_big       = fw_resize( $thumbnail->ID, $thumbnails_params_big[ 'width' ], $thumbnails_params_big[ 'height' ], $thumbnails_params_big[ 'crop' ] );
							$thumbnail_title = $thumbnail->post_title;
						} else {
							$image           = fw()->extensions->get( 'services' )->locate_URI( '/static/img/no-photo.jpg' );
							$image_big       = fw()->extensions->get( 'services' )->locate_URI( '/static/img/no-photo.jpg' );
							$thumbnail_title = $image;
						}

						$service_small_desc = fw_get_db_post_option( get_the_ID(), 'small-description' );
						$icon_image         = false;

						?>


                        <li class="col-sm-12 col-md-6 <?php echo ( ! empty( $loop_data[ 'listing_classes' ][ get_the_ID() ] ) ) ? $loop_data[ 'listing_classes' ][ get_the_ID() ] : ''; ?>">
                            <div class="services-item"
                                 style="background-image: url(<?php echo esc_url( $image ); ?>)">
                                <div class="services-item--wrapper fw-iconbox fw-iconbox--top ib-type1">
                                    <div class="services-item--image fw-iconbox__image">
										<?php
										// Service Icon
										$get_fw_ext_services_get_icon = fw_ext_services_get_icon( get_the_ID() );
										if ( empty( $get_fw_ext_services_get_icon ) ) { ?>
                                            <i class="services-item--icon fa fa-circle fa--empty"></i>
										<?php } else { ?>
                                            <i class="services-item--icon <?php echo esc_attr( fw_ext_services_get_icon( get_the_ID() ) ); ?>"></i>
										<?php } ?>

										<?php if ( $icon_image == true ): ?>
                                            <a href="<?php the_permalink() ?>">
                                                <img src="<?php echo esc_url( $image ); ?>"
                                                     alt="<?php echo esc_attr( $thumbnail_title ); ?>"
                                                     width="<?php echo esc_attr( $thumbnails_params[ 'width' ] ); ?>"
                                                     height="<?php echo esc_attr( $thumbnails_params[ 'height' ] ); ?>"/>
                                            </a>
										<?php endif; ?>
                                    </div>
                                    <div class="services-item--inner fw-iconbox__aside">
                                        <div class="services-item--title fw-iconbox__title">
                                        <h3><a
                                                    href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
										<?php $oildrop_get_custom_shortdesc = oildrop_get_custom_shortdesc_box( get_the_ID() )[ 0 ]; ?>
                                        </div>
                                        <div class="services-item--text fw-iconbox__text">
                                            <div>
											<?php if ( ! empty( $service_small_desc ) || ! empty( $oildrop_get_custom_shortdesc ) ) : ?>
												<?php
												if ( ! empty( $oildrop_get_custom_shortdesc ) ) {
													echo esc_attr( $oildrop_get_custom_shortdesc );
												} else {
													echo esc_attr( $service_small_desc );
												} ?>
											<?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="services-item--readmore">
                                            <a href="<?php the_permalink() ?>"
                                               class="button"><?php echo esc_html__( 'Read More', 'oildrop' ); ?></a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </li>


					<?php endwhile; ?>
                    <li class="clear"></li>
                </ul>
            </div>


			<?php
			unset( $ext_services_instance );
			unset( $ext_services_settings );
			set_query_var( 'fw_services_loop_data', '' );
			?>

			<?php echo wp_kses_post( $args[ 'after_widget' ] ); ?>
			<?php
			// Reset the global $the_post as this query will have stomped on it
			wp_reset_postdata();

		endif;

		if ( ! $this->is_preview() ) {
			$cache[ $args[ 'widget_id' ] ] = ob_get_flush();
			wp_cache_set( 'widget_services_row', $cache, 'widget' );
		} else {
			ob_end_flush();
		}
	}

	public function update( $new_instance, $old_instance ) {
		$instance               = $old_instance;
		$instance[ 'title' ]    = strip_tags( $new_instance[ 'title' ] );
		$instance[ 'number' ]   = (int) $new_instance[ 'number' ];
		$instance[ 'category' ] = $new_instance[ 'category' ];

		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset( $alloptions[ 'widget_services_row' ] ) ) {
			delete_option( 'widget_services_row' );
		}

		return $instance;
	}

	public function form( $instance ) {
		$title    = isset( $instance[ 'title' ] ) ? esc_attr( $instance[ 'title' ] ) : '';
		$number   = isset( $instance[ 'number' ] ) ? absint( $instance[ 'number' ] ) : 3;
		$category = isset( $instance[ 'category' ] ) ? $instance[ 'category' ] : '';

		?>
        <p>
            <label
                    for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo wp_kses( __( 'Title', 'oildrop' ), $allowed_html_array = array (
					'br' => array (),
					'i'  => array ()
				) ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
                   value="<?php echo esc_attr( $title ); ?>"/>
        </p>

        <p>
            <label
                    for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php echo wp_kses( __( 'Number of services<br><i>to show</i>', 'oildrop' ), $allowed_html_array = array (
					'br' => array (),
					'i'  => array ()
				) ); ?></label>

            <select id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"
                    name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>">
                <option <?php selected( $number, '1' ); ?>
                        value="1"><?php esc_html_e( '1', 'oildrop' ) ?></option>
                <option <?php selected( $number, '2' ); ?>
                        value="2"><?php esc_html_e( '2', 'oildrop' ) ?></option>
                <option <?php selected( $number, '3' ); ?>
                        value="3"><?php esc_html_e( '3', 'oildrop' ) ?></option>
            </select>

        </p>

        <p><label
                    for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>"><?php echo wp_kses( __( 'Category<br><i>services category</i>', 'oildrop' ), $allowed_html_array = array (
					'br' => array (),
					'i'  => array ()
				) ); ?></label>
			<?php
			wp_dropdown_categories( array (
				'show_option_all' => esc_html__( 'All', 'oildrop' ),
				'hide_empty'      => 0,
				'selected'        => $category,
				'name'            => $this->get_field_name( 'category' ),
				'id'              => $this->get_field_id( 'category' ),
				'taxonomy'        => 'fw-services-category',
				'value_field'     => 'slug'
			) );
			?>
        </p>

		<?php
	}
}

if ( ! function_exists( 'oildrop_services_row_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function oildrop_services_row_setup() {
		if ( ! has_image_size( 'oildrop_top-news-3-2' ) ) {
			add_image_size( 'oildrop_top-news-3-2', 770, 513, true );
		}
		if ( ! has_image_size( 'oildrop_top-news-3-3' ) ) {
			add_image_size( 'oildrop_top-news-3-3', 770, 770, true );
		}
	}
endif; // oildrop_top_news_setup
add_action( 'after_setup_theme', 'oildrop_services_row_setup', 20 );

if ( ! function_exists( 'oildrop_register_widget_services_row_carousel' ) ) :
	function oildrop_register_widget_services_row_carousel() {
		register_widget( 'OILDROP_Widget_Services_Row' );
	}
endif;
add_action( 'widgets_init', 'oildrop_register_widget_services_row_carousel' );
// Style and script included in main files