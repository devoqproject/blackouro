<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

wp_enqueue_script(
	'fw-shortcode-skills-bar-script',
	get_template_directory_uri() . '/framework-customizations/extensions/shortcodes/shortcodes/skills-bar/static/js/skills-bar-script.js',
	true
);
