<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * @var array $atts
 */

$image = ! empty( $atts[ 'image' ][ 'url' ] ) ? $atts[ 'image' ][ 'url' ] : '';
$title = $atts[ 'box_title' ];
$icon  = $icon_sublist = '';
$list  = 'ul';
if ( $atts[ 'list_type' ][ 'selected_value' ] == 'list-numbers' ) {
	$list = 'ol';
}

?>
<div class="fw-listbox">
    <div class="fw-listbox-image">
        <?php
        if ( ! empty( $image) ) {
	        echo '<img src="' . esc_url( $image ) . '" alt="' . esc_attr__( 'Image', 'oildrop' ) . '" />';
        }
        ?>
    </div>
    <div class="fw-listbox-title-wrap">
		<?php if ( ! empty( $title ) ): ?>
            <h4 class="fw-listbox-title"><?php echo esc_attr( $title ); ?></h4>
		<?php endif; ?>
    </div>
    <div class="fw-list <?php echo esc_attr( $atts[ 'list_type' ][ 'selected_value' ] ); ?> <?php echo esc_attr( $atts[ 'class' ] ); ?>">
        <<?php echo esc_attr( $list ); ?>>
		<?php if ( ! empty( $atts[ 'list_items' ] ) ) : ?>

			<?php foreach ( $atts[ 'list_items' ] as $list_item ) :

				if ( $atts[ 'list_type' ][ 'selected_value' ] == 'list-icon' ) {
					$icon_size = ! empty( $atts[ 'list_type' ][ 'list-icon' ][ 'icon_size' ] ) ? 'font-size:' . esc_attr( (int) $atts[ 'list_type' ][ 'list-icon' ][ 'icon_size' ] ) . 'px;' : '';
					$icon      = '<i class="' . $atts[ 'list_type' ][ 'list-icon' ][ 'icon' ] . '" style="' . $icon_size . '"></i>';
				} elseif ( $atts[ 'list_type' ][ 'selected_value' ] == 'upload-icon' ) {
					if ( isset( $atts[ 'list_type' ][ 'upload-icon' ][ 'upload-custom-img' ][ 'url' ] ) && ! empty( $atts[ 'list_type' ][ 'upload-icon' ][ 'upload-custom-img' ][ 'url' ] ) ) {
						$icon_size = ! empty( $atts[ 'list_type' ][ 'upload-icon' ][ 'icon_size' ] ) ? 'width:' . esc_attr( (int) $atts[ 'list_type' ][ 'upload-icon' ][ 'icon_size' ] ) . 'px;' : '';
						$icon      = '<img src="' . esc_url( $atts[ 'list_type' ][ 'upload-icon' ][ 'upload-custom-img' ][ 'url' ] ) . '"  style="' . $icon_size . '" />';
					}
				} ?>

                <li><?php echo wp_kses( $icon, oildrop_kses_list() ); ?>

					<?php if ( $list_item[ 'link' ] != '' ) {
						$a_class = '';
						if ( strpos( $list_item[ 'link' ], "#" ) !== false && strlen( $list_item[ 'link' ] ) > 1 ) {
							$a_class = 'class="anchor"';
						}
						echo '<a ' . $a_class . ' href="' . esc_url( do_shortcode( $list_item[ 'link' ] ) ) . '" target="' . esc_attr( $list_item[ 'target' ] ) . '">' . esc_attr( $list_item[ 'item' ] ) . '</a>';
					} else {
						echo esc_attr( $list_item[ 'item' ] );
					} ?>

                </li>

			<?php endforeach; ?>

		<?php endif; ?>
    </<?php echo esc_attr( $list ); ?>>
</div>
</div>