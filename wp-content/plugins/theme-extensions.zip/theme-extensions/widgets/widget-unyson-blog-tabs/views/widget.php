<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}
/**
 * @var string $before_widget
 * @var string $after_widget
 * @var array $recent_posts
 * @var array $popular_posts
 */

echo wp_kses_post( $before_widget );
?>

<div class="wrap-blog-tabs">

    <!-- Nav tabs -->
    <ul class="nav nav-tabs" role="tablist">
        <li role="blogtabs" class="active"><a href="#popular_posts" aria-controls="popular_posts" role="tab"
                                              data-toggle="tab"><?php esc_html_e( 'Posts', 'oildrop' ); ?></a></li>
        <li role="blogtabs"><a href="#most_commented" aria-controls="settings" role="tab"
                               data-toggle="tab"><?php esc_html_e( 'Most Commented', 'oildrop' ); ?></a></li>
    </ul>

    <!-- Tab panes -->
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane active widget_popular_posts" id="popular_posts">
            <ul>
				<?php foreach ( $recent_posts as $post ): ?>
                    <li>
                        <a href="<?php echo esc_url( $post[ 'post_link' ] ); ?>"><?php echo esc_attr( $post[ 'post_title' ] ); ?></a>
                    </li>
				<?php endforeach; ?>
            </ul>
        </div>
        <div role="tabpanel" class="tab-pane widget_most_commented" id="most_commented">
            <ul>
				<?php foreach ( $popular_posts as $post ): ?>
                    <li>
                        <a href="<?php echo esc_url( $post[ 'post_link' ] ); ?>"><?php echo esc_attr( $post[ 'post_title' ] ); ?></a>
                    </li>
				<?php endforeach; ?>
            </ul>
        </div>

    </div>

</div>

<?php echo wp_kses_post( $after_widget ); ?>
