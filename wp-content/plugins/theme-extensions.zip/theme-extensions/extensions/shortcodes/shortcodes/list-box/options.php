<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array (
	'unique_id'  => array (
		'type' => 'unique'
	),
	'list_group' => array (
		'type'    => 'group',
		'options' => array (
			'box-title' => array(
				'label' => esc_html__( 'Tiesc_htmltle', 'oildrop' ),
				'desc'  => esc_html__( 'Enter the image box title', 'oildrop' ),
				'type'  => 'text',
			),
			'image' => array(
				'label' => esc_html__( 'Image', 'oildrop' ),
				'desc'  => esc_html__( 'Upload an image', 'oildrop' ),
				'type'  => 'upload',
			),
			'list_items' => array (
				'attr'          => array ( 'class' => 'button-advanced' ),
				'type'          => 'addable-popup',
				'size'          => 'medium',
				'label'         => esc_html__( 'List Items', 'oildrop' ),
				'desc'          => esc_html__( 'Add list items', 'oildrop' ),
				'template'      => '{{=item}}',
				'popup-options' => array (
					'sublist_group'  => array (
						'type'    => 'group',
						'options' => array (
							'item'          => array (
								'label' => esc_html__( 'Item', 'oildrop' ),
								'desc'  => esc_html__( 'Enter an item in list', 'oildrop' ),
								'type'  => 'text',
							),
						)
					),
					'btn_link_group' => array (
						'type'    => 'group',
						'options' => array (
							'link'   => array (
								'label' => esc_html__( 'Link', 'oildrop' ),
								'desc'  => esc_html__( 'Where should your button link to?', 'oildrop' ),
								'type'  => 'text',
								'value' => '#'
							),
							'target' => array (
								'type'         => 'switch',
								'label'        => esc_html__( '', 'oildrop' ),
								'desc'         => esc_html__( 'Open link in new window?', 'oildrop' ),
								'value'        => '_self',
								'right-choice' => array (
									'value' => '_blank',
									'label' => esc_html__( 'Yes', 'oildrop' ),
								),
								'left-choice'  => array (
									'value' => '_self',
									'label' => esc_html__( 'No', 'oildrop' ),
								),
							),
						)
					),
				),
			),
		)
	),
	'list_type'  => array (
		'type'         => 'multi-picker',
		'label'        => false,
		'desc'         => false,
		'picker'       => array (
			'selected_value' => array (
				'label'   => esc_html__( 'Add Element', 'oildrop' ),
				'desc'    => esc_html__( 'Make a numbered list or add an icon to list items', 'oildrop' ),
				'attr'    => array ( 'class' => 'fw-checkbox-float-left' ),
				'value'   => 'list-default',
				'type'    => 'radio',
				'choices' => array (
					'list-default' => esc_html__( 'None', 'oildrop' ),
					'list-numbers' => esc_html__( 'Number', 'oildrop' ),
					'list-icon'    => esc_html__( 'Icon', 'oildrop' ),
					'upload-icon'  => esc_html__( 'Custom Upload', 'oildrop' ),
				),
			)
		),
		'choices'      => array (
			'list-default' => array (),
			'list-numbers' => array (),
			'list-icon'    => array (
				'icon' => array (
					'type'  => 'icon',
					'label' => esc_html__( '', 'oildrop' ),
					'set'   => 'theme-icons',
				),
				'icon_size' => array(
					'label' => esc_html__( 'Icon Size', 'oildrop' ),
					'desc'  => esc_html__( 'Enter the icon size in pixels', 'oildrop' ),
					'value' => '15',
					'type'  => 'short-text'
				),
			),
			'upload-icon'  => array (
				'upload-custom-img' => array (
					'label' => '',
					'type'  => 'upload',
				),
				'icon_size'         => array (
					'label' => esc_html__( 'Icon Size', 'oildrop' ),
					'desc'  => esc_html__( 'Enter the icon width in pixels', 'oildrop' ),
					'value' => '15',
					'type'  => 'short-text'
				),
			),
		),
		'show_borders' => false,
	),
	'description_group' => array(
		'type'    => 'group',
		'options' => array(
			'box-desc'                     => array(
				'attr'    => array( 'class' => 'description-advanced' ),
				'label'   => esc_html__( 'Description', 'oildrop' ),
				'desc'    => esc_html__( 'Enter the image box description', 'oildrop' ),
				'type'    => 'wp-editor',
				'tinymce' => true,
				'wpautop' => true,
				'shortcodes' => true,
				'value'   => '',
			),
		)
	),
	'class'      => array (
		'label' => esc_html__( 'Custom Class', 'oildrop' ),
		'desc'  => esc_html__( 'Enter custom CSS class', 'oildrop' ),
		'type'  => 'text',
		'value' => '',
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS in the', 'oildrop' ) . ' <strong>' . esc_html__( 'custom.less', 'oildrop' ) . '</strong>' . esc_html__( ' file. This file is located on your server in the ', 'oildrop' ) . '<strong>' . esc_html__( '/child-theme/styles-less/', 'oildrop' ) . '</strong>' . esc_html__( ' folder.', 'oildrop' ),
	),
);