<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

class OILDROP_Unyson_Flickr extends WP_Widget {

	/**
	 * @internal
	 */
	function __construct() {
		$widget_ops = array ( 'description' => '' );
		parent::__construct( false, esc_html__( 'Flickr', 'oildrop' ), $widget_ops );
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	function widget( $args, $instance ) {
		extract( $args );

		$flickr_id     = esc_attr( $instance[ 'flickr_id' ] );
		$title         = esc_attr( $instance[ 'title' ] );
		$number        = ( (int) ( esc_attr( $instance[ 'number' ] ) ) > 0 ) ? esc_attr( $instance[ 'number' ] ) : 9;
		$before_widget = str_replace( 'class="', 'class="widget_flickr_image_gallery ', $before_widget );
		$title         = str_replace( 'class="', 'class="widget_flickr_image_gallery ', $before_title ) . $title . $after_title;

		wp_enqueue_script(
			'fw-theme-flickr-widget',
			plugin_dir_url( __FILE__ ) . 'static/js/scripts.js',
			array ( 'jquery' ),
			'1.0'
		);

		$filepath = plugin_dir_path(__FILE__ ) . 'views/widget.php';

		if ( file_exists( $filepath ) ) {
			include( $filepath );
		}
	}

	function update( $new_instance, $old_instance ) {
		return $new_instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array ( 'flickr_id' => '', 'number' => '', 'title' => '' ) );
		?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'oildrop' ); ?> </label>
            <input type="text" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
                   value="<?php echo esc_attr( $instance[ 'title' ] ); ?>" class="widefat"
                   id="<?php $this->get_field_id( 'title' ); ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'flickr_id' ) ); ?>"><?php esc_html_e( 'Flickr ID', 'oildrop' ); ?>
                (<a
                        href="http://www.idgettr.com" target="_blank">idGettr</a>):</label>
            <input type="text" name="<?php echo esc_attr( $this->get_field_name( 'flickr_id' ) ); ?>"
                   value="<?php echo esc_attr( $instance[ 'flickr_id' ] ); ?>" class="widefat"
                   id="<?php $this->get_field_id( 'flickr_id' ); ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of photos', 'oildrop' ); ?>
                :</label>
            <input type="text" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>"
                   value="<?php echo esc_attr( $instance[ 'number' ] ); ?>" class="widefat"
                   id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"/>
        </p>
		<?php
	}
}

if ( ! function_exists( 'oildrop_register_widget_unyson_flickr' ) ) :
	function oildrop_register_widget_unyson_flickr() {
		register_widget( 'OILDROP_Unyson_Flickr' );
	}
endif;
add_action( 'widgets_init', 'oildrop_register_widget_unyson_flickr' );
