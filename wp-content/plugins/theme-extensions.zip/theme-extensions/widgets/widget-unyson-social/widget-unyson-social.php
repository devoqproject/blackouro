<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

class OILDROP_Unyson_Social extends WP_Widget {

	function __construct() {
		$widget_ops = array ( 'description' => esc_html__( 'Social links', 'oildrop' ) );

		parent::__construct( false, esc_html__( 'Social', 'oildrop' ), $widget_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );
		$params = array ();

		foreach ( $instance as $key => $value ) {
			$params[ $key ] = $value;
		}

		if ( ! empty( $params[ 'widget-title' ] ) ) {
			$title = $before_title . $params[ 'widget-title' ] . $after_title;
		}
		unset( $params[ 'widget-title' ] );

		$filepath = plugin_dir_path(__FILE__ ) . 'views/widget.php';

		$instance      = $params;
		$before_widget = str_replace( 'class="', 'class="widget_social_links ', $before_widget );

		if ( file_exists( $filepath ) ) {
			include( $filepath );
		}
	}

	function update( $new_instance, $old_instance ) {
		$instance = wp_parse_args( (array) $new_instance, $old_instance );

		return $instance;
	}

	function form( $instance ) {

		$titles = array (
			'widget-title' => esc_html__( 'Social Title:', 'oildrop' ),
			'google'       => esc_html__( 'Google URL:', 'oildrop' ),
			'facebook'     => esc_html__( 'Facebook URL:', 'oildrop' ),
			'twitter'      => esc_html__( 'Twitter URL:', 'oildrop' ),
			'dribbble'     => esc_html__( 'Dribbble URL:', 'oildrop' ),
			'vimeo-square' => esc_html__( 'Vimeo-square URL:', 'oildrop' ),
			'linkedin'     => esc_html__( 'Linkedin URL:', 'oildrop' ),
			'instagram'    => esc_html__( 'Instagram URL:', 'oildrop' )
		);

		$instance = wp_parse_args( (array) $instance, $titles );

		$exclude = array (
			'width',
			'offset_left',
			'offset_right',
			'offset_top',
			'oildrop_rc_show_avatar',
			'oildrop_rp_category',
			'oildrop_rp_show_views',
			'oildrop_rp_show_likes',
			'oildrop_rp_layout',
		);

		foreach ( $instance as $key => $value ) {
			if ( ! in_array( $key, $exclude ) ) {
				?>
                <p>
                    <label><?php echo esc_attr( $titles[ $key ] ); ?></label>
                    <input class="widefat widget_social_link widget_link_field"
                           name="<?php echo esc_attr( $this->get_field_name( $key ) ); ?>" type="text"
                           value="<?php echo esc_attr( ( $instance[ $key ] === $titles[ $key ] ) ? '' : $instance[ $key ] ); ?>"/>
                </p>
				<?php
			}
		}
	}
}

if ( ! function_exists( 'oildrop_register_widget_unyson_social' ) ) :
	function oildrop_register_widget_unyson_social() {
		register_widget( 'OILDROP_Unyson_Social' );
	}
endif;
add_action( 'widgets_init', 'oildrop_register_widget_unyson_social' );
