<?php
/**
 * Deprecated functions.
 *
 * @package    CustomContentTeam
 * @subpackage Includes
 * @author     Justin Tadlock <justin@justintadlock.com>
 * @copyright  Copyright (c) 2013-2015, Justin Tadlock
 * @license    http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

/* === Functions removed in 1.0.0 === */

function cct_sanitize_meta() {}
function cct_breadcrumb_trail_items() {}
function cct_add_meta_boxes() {}
function cct_team_item_info_meta_box_display() {}
function cct_team_item_info_meta_box_save() {}
function cct_admin_head_style() {}
function cct_plugin_settings() {}
function cct_validate_settings() {}
function cct_permalink_section() {}
function cct_root_field() {}
function cct_base_field() {}
function cct_item_base_field() {}
function cct_admin_setup() {}
function cct_edit_team_item_columns() {}
function cct_manage_team_item_columns() {}
