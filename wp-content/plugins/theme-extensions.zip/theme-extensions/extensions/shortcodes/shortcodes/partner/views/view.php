<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * @var array $atts
 */

if ( empty( $atts[ 'image' ] ) ) {
	return;
}

if ( empty( $atts[ 'image_alt' ] ) ) {
	$atts[ 'image_alt' ] = '';
}

$width  = '';
$height = '';

if ( ! empty( $width ) && ! empty( $height ) ) {
	$image = fw_resize( $atts[ 'image' ][ 'attachment_id' ], $width, $height, true );
} else {
	$image = $atts[ 'image' ][ 'url' ];
}

if ( ! empty( $width ) && ! empty( $height ) ) {
	$image_alt = fw_resize( $atts[ 'image_alt' ][ 'attachment_id' ], $width, $height, true );
} else {
	if ( ! empty( $atts[ 'image_alt' ][ 'url' ] ) ) {
		$image_alt = $atts[ 'image_alt' ][ 'url' ];
	} else {
		$image_alt = '';
	}

}

$alt = get_post_meta( $atts[ 'image' ][ 'attachment_id' ], '_wp_attachment_image_alt', true );
if ( ! empty( $atts[ 'image_alt' ][ 'url' ] ) ) {
	$alt_alt = get_post_meta( $atts[ 'image_alt' ][ 'attachment_id' ], '_wp_attachment_image_alt', true );
} else {
	$alt_alt = '';
}

$img_attributes = array (
	'src' => $image,
	'alt' => $alt ? $alt : $image
);

$img_attributes_alt = array (
	'src' => $image_alt,
	'alt' => $alt ? $alt : $image_alt
);

if ( ! empty( $width ) ) {
	$img_attributes[ 'width' ] = $width;
}

if ( ! empty( $height ) ) {
	$img_attributes[ 'height' ] = $height;
}

// Print

if ( empty( $atts[ 'link' ] ) ) {
	echo fw_html_tag( 'img', $img_attributes );
} else {
	if ( $image_alt == '' ) {
		echo '<a class="partner-link partner-link-single" href="' . esc_url( do_shortcode( $atts[ 'link' ] ) ) . '" target="' . $atts[ 'target' ] . '">';
		echo fw_html_tag( 'img', $img_attributes );
		echo '</a>';
	} else {
		echo '<a class="partner-link partner-link-multiple" href="' . esc_url( do_shortcode( $atts[ 'link' ] ) ) . '" target="' . $atts[ 'target' ] . '">';
		echo fw_html_tag( 'img', $img_attributes );
		echo fw_html_tag( 'img', $img_attributes_alt );
		echo '</a>';
	}
}
