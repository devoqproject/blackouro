<?php
/**
 * Recent_Posts customized widget class.0
 */
if ( ! function_exists( 'oildrop_recent_posts_display_callback' ) ) :
	function oildrop_recent_posts_display_callback( $instance, $widget, $args ) {
		if ( 'recent-posts' == $widget->id_base ) {

			if ( ! isset( $args[ 'widget_id' ] ) ) {
				$args[ 'widget_id' ] = $widget->id;
			}

			$unique_id = uniqid();

			ob_start();

			$title = ( ! empty( $instance[ 'title' ] ) ) ? $instance[ 'title' ] : esc_html__( '', 'oildrop' );

			/** This filter is documented in wp-includes/default-widgets.php */
			$title    = apply_filters( 'widget_title', $title, $instance, $widget->id_base );
			$category = isset( $instance[ 'oildrop_rp_category' ] ) ? $instance[ 'oildrop_rp_category' ] : '';

			$layout = isset( $instance[ 'oildrop_rp_layout' ] ) ? absint( $instance[ 'oildrop_rp_layout' ] ) : 1;

			$number = ( ! empty( $instance[ 'number' ] ) ) ? absint( $instance[ 'number' ] ) : 5;
			if ( ! $number ) {
				$number = 5;
			}

			$show_date  = isset( $instance[ 'show_date' ] ) ? $instance[ 'show_date' ] : false;
			$show_views = function_exists( 'oildrop_get_post_views' ) && isset( $instance[ 'oildrop_rp_show_views' ] ) ? $instance[ 'oildrop_rp_show_views' ] : false;
			$show_likes = function_exists( 'oildrop_get_post_likes' ) && isset( $instance[ 'oildrop_rp_show_likes' ] ) ? $instance[ 'oildrop_rp_show_likes' ] : false;

			$cat_exclude     = '';
			$main_slider_cat = oildrop_get_main_slider_category();
			if ( $main_slider_cat[ 'id' ] ) {
				$cat_exclude = - $main_slider_cat[ 'id' ];
			}

			/**
			 * Filter the arguments for the Recent Posts widget.
			 *
			 * @since 3.4.0
			 *
			 * @see WP_Query::get_posts()
			 *
			 * @param array $args An array of arguments used to retrieve the recent posts.
			 */
			$r = new WP_Query( apply_filters( 'widget_posts_args', array (
				'posts_per_page'      => $number,
				'no_found_rows'       => true,
				'post_status'         => 'publish',
				'category_name'       => $category,
				'ignore_sticky_posts' => true,
				'cat'                 => $cat_exclude,
			) ) );

			if ( $r->have_posts() ) :

				$thumbnail_args = array (
					'background'      => false,
					'print'           => true,
					'thumbnail_size'  => 'oildrop_top-news-3-2',
					'thumbnail_class' => 'recent-posts__media',
					'use_default'     => true,
					'is_widget'       => true,
					'no_url'          => true,
				);

				$thumbnail_args_bg = array (
					'background'      => true,
					'print'           => false,
					'thumbnail_size'  => 'oildrop_top-news-3-2',
					'thumbnail_class' => 'recent-posts__media',
					'use_default'     => true,
					'is_widget'       => true,
					'no_url'          => true,
				);

				$thumbnail_url = array (
					'background'      => true,
					'print'           => false,
					'thumbnail_size'  => 'oildrop_top-news-3-2',
					'thumbnail_class' => 'recent-posts__media',
					'use_default'     => true,
					'is_widget'       => true,
					'no_url'          => true,
					'only_url'        => true,
				);

                echo wp_kses_post( $args[ 'before_widget' ] );

                // Title / if not empty
				if ( $title ) {
				    echo wp_kses_post( $args[ 'before_title' ] . $title . $args[ 'after_title' ] );
			    }

			    ?>
                <ul <?php echo 'class="recent-posts layout-' . $layout . '"'; ?>><!--
				<?php while ( $r->have_posts() ) :
					$r->the_post(); ?>
					--><li>
                        <div class="recent-posts__inner"><?php

							$pID = get_the_ID();

							// Post Media
	                        if ( $layout == '2' || $layout == '3' ) {

		                        echo '<a class="recent-posts__media" href="' . esc_url( get_the_permalink( $pID ) ) . '"><span class="overlay ' . get_post_format() . '"></span>';

		                        // Post Likes Count
		                        if ( function_exists( 'oildrop_get_post_likes' ) && $show_likes ) {
			                        echo '<span class="recent-posts__likes"><i class="recent-posts__icon fa fa-heart-o"></i>' . oildrop_get_post_likes( $pID ) . '</span>';
		                        }

		                        // Post Image
		                        oildrop_post_thumbnail( $thumbnail_args );

		                        echo '</a>';

	                        }

	                        // Post Media
	                        if ( $layout == '1' ) {

		                        echo '<a class="recent-posts__media" style="' . oildrop_post_thumbnail( $thumbnail_args_bg ) . '" href="' . esc_url( get_the_permalink( $pID ) ) . '"><span class="overlay ' . get_post_format() . '"></span>';

		                        // Post Likes Count
		                        if ( function_exists( 'oildrop_get_post_likes' ) && $show_likes ) {
			                        echo '<span class="recent-posts__likes"><i class="recent-posts__icon fa fa-heart-o"></i>' . oildrop_get_post_likes( $pID ) . '</span>';
		                        }

		                        echo '</a>';

	                        } ?>


                            <span class="recent-posts__content">

                                <span class="recent-posts__content_inner"><?php

                                // Post Description
                                if ( $layout == '3' ) { ?>
                                <span class="recent-posts__category">
                                    <?php echo oildrop_get_first_category( get_the_ID() ); ?>
                                </span>
                                <?php } ?>

                                <a class="recent-posts__title" href="<?php esc_url( the_permalink() ); ?>">
                                    <?php get_the_title() ? the_title() : the_ID(); ?>
                                </a><?php

                                // Post Description
		                        if ( $layout == '3' ) { ?>
                                    <span class="recent-posts__description"><?php echo get_the_excerpt(); ?></span>
		                        <?php } ?>

                                </span><?php // .recent-posts__content_height

		                        // Post Meta Wrapper
				                if ( $show_date || ( function_exists( 'oildrop_get_post_views' ) && $show_views ) ) {
					                echo '<span class="recent-posts__meta">';
                                }

		                        // Post Date
		                        if ( $show_date ) { ?>
                                    <span class="recent-posts__date"><?php echo get_the_date( 'd.m.Y' ); ?></span>
		                        <?php }

		                        // Post Views Count
		                        if ( function_exists( 'oildrop_get_post_views' ) && $show_views ) {
			                        $post_views = oildrop_get_post_views( $pID ); ?>
                                    <span class="recent-posts__views"><?php echo oildrop_plural_text( $post_views, esc_html__( 'view', 'oildrop' ), esc_html__( 'views', 'oildrop' ) ); ?></span>
		                        <?php }

	                            // Close Post Meta Wrapper
	                            if ( $show_date || ( function_exists( 'oildrop_get_post_views' ) && $show_views ) ) {
		                            echo '</span>'; // .recent-posts__meta
	                            }

		                        ?>
                            </span><!-- .recent-posts__content -->
                        </div>
                    </li><!--
				<?php endwhile; ?>
			--></ul>
				<?php echo wp_kses_post( $args[ 'after_widget' ] ); ?>
				<?php
				// Reset the global $the_post as this query will have stomped on it
				wp_reset_postdata();

			endif;

			if ( ! $widget->is_preview() ) {
				$cache[ $args[ 'widget_id' ] ] = ob_get_flush();
				wp_cache_set( 'widget_recent_posts', $cache, 'widget' );
			} else {
				ob_end_flush();
			}

			return false;
		}

		return $instance;
	}
endif;
add_filter( 'widget_display_callback', 'oildrop_recent_posts_display_callback', 10, 3 );

if ( ! function_exists( 'oildrop_save_recent_posts_custom_options' ) ) :
	function oildrop_save_recent_posts_custom_options( $instance, $new_instance ) {

		$instance[ 'oildrop_rp_category' ] = $new_instance[ 'oildrop_rp_category' ];
		if ( function_exists( 'oildrop_get_post_views' ) ) {
			$instance[ 'oildrop_rp_show_views' ] = isset( $new_instance[ 'oildrop_rp_show_views' ] ) ? (bool) $new_instance[ 'oildrop_rp_show_views' ] : false;
		}
		if ( function_exists( 'oildrop_get_post_likes' ) ) {
			$instance[ 'oildrop_rp_show_likes' ] = isset( $new_instance[ 'oildrop_rp_show_likes' ] ) ? (bool) $new_instance[ 'oildrop_rp_show_likes' ] : false;
		}
		$instance[ 'oildrop_rp_layout' ] = (int) $new_instance[ 'oildrop_rp_layout' ];
		if ( file_exists(  plugin_dir_path(__FILE__ ) . "images/recent_posts_bg.jpg" ) ) {
			$instance[ 'oildrop_rp_background' ] = (int) $new_instance[ 'oildrop_rp_background' ];
		}

		return $instance;
	}
endif;
add_filter( 'widget_update_callback', 'oildrop_save_recent_posts_custom_options', 10, 2 );

if ( ! function_exists( 'oildrop_add_recent_posts_custom_options' ) ) :
	function oildrop_add_recent_posts_custom_options( $widget, $return, $instance ) {

		if ( 'recent-posts' == $widget->id_base ) {

			$category = isset( $instance[ 'oildrop_rp_category' ] ) ? $instance[ 'oildrop_rp_category' ] : '';

			if ( function_exists( 'oildrop_get_post_views' ) ) {
				$show_views = isset( $instance[ 'oildrop_rp_show_views' ] ) ? (bool) $instance[ 'oildrop_rp_show_views' ] : false;
			}
			if ( function_exists( 'oildrop_get_post_likes' ) ) {
				$show_likes = isset( $instance[ 'oildrop_rp_show_likes' ] ) ? (bool) $instance[ 'oildrop_rp_show_likes' ] : false;
			}
			$layout = isset( $instance[ 'oildrop_rp_layout' ] ) ? absint( $instance[ 'oildrop_rp_layout' ] ) : 0;

			?>

			<?php if ( function_exists( 'oildrop_get_post_views' ) ) { ?>
                <p><input class="checkbox" type="checkbox" <?php checked( $show_views ); ?>
                          id="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_show_views' ) ); ?>"
                          name="<?php echo esc_attr( $widget->get_field_name( 'oildrop_rp_show_views' ) ); ?>"/>
                    <label for="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_show_views' ) ); ?>"><?php esc_attr_e( 'Display post views?', 'oildrop' ); ?></label>
                </p>
				<?php
			}

			if ( function_exists( 'oildrop_get_post_likes' ) ) { ?>
                <p><input class="checkbox" type="checkbox" <?php checked( $show_likes ); ?>
                          id="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_show_likes' ) ); ?>"
                          name="<?php echo esc_attr( $widget->get_field_name( 'oildrop_rp_show_likes' ) ); ?>"/>
                    <label for="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_show_likes' ) ); ?>"><?php esc_attr_e( 'Display post likes?', 'oildrop' ); ?></label>
                </p>

				<?php
			}
			?>

            <p>
                <label for="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_category' ) ); ?>"><?php esc_attr_e( 'Category:', 'oildrop' ); ?></label>
				<?php wp_dropdown_categories( array (
					'show_option_all' => esc_html__( 'All Categories', 'oildrop' ),
					'hide_empty'      => 0,
					'selected'        => $category,
					'name'            => $widget->get_field_name( 'oildrop_rp_category' ),
					'id'              => $widget->get_field_id( 'oildrop_rp_category' ),
					'value_field'     => 'slug'
				) ); ?>
            </p>

            <p>
                <strong><?php esc_attr_e( 'Layout:', 'oildrop' ); ?></strong><br>
                <label for="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_list-0' ) ); ?>"
                       class="recent-posts-radio-label">
                    <input class="recent-posts-radio" type="radio" <?php checked( $layout == 0 ); ?>
                           id="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_list-0' ) ); ?>"
                           name="<?php echo esc_attr( $widget->get_field_name( 'oildrop_rp_layout' ) ); ?>" value="0"/>
                    <img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/recent-posts-list-0.gif'; ?>"
                         alt="<?php echo esc_attr__( 'List', 'oildrop' ); ?>">
                </label>
                <label for="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_list' ) ); ?>"
                       class="recent-posts-radio-label">
                    <input class="recent-posts-radio" type="radio" <?php checked( $layout == 1 ); ?>
                           id="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_list' ) ); ?>"
                           name="<?php echo esc_attr( $widget->get_field_name( 'oildrop_rp_layout' ) ); ?>" value="1"/>
                    <img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/recent-posts-list.gif'; ?>"
                         alt="<?php echo esc_attr__( 'List', 'oildrop' ); ?>">
                </label>
                <label for="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_grid-1' ) ); ?>"
                       class="recent-posts-radio-label">
                    <input class="recent-posts-radio" type="radio" <?php checked( $layout == 2 ); ?>
                           id="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_grid-1' ) ); ?>"
                           name="<?php echo esc_attr( $widget->get_field_name( 'oildrop_rp_layout' ) ); ?>" value="2"/>
                    <img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/recent-posts-grid-big.gif'; ?>"
                         alt="<?php echo esc_attr__( 'Grid 1', 'oildrop' ); ?>">
                </label>
                <label for="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_grid-2' ) ); ?>"
                       class="recent-posts-radio-label">
                    <input class="recent-posts-radio" type="radio" <?php checked( $layout == 3 ); ?>
                           id="<?php echo esc_attr( $widget->get_field_id( 'oildrop_rp_grid-2' ) ); ?>"
                           name="<?php echo esc_attr( $widget->get_field_name( 'oildrop_rp_layout' ) ); ?>" value="3"/>
                    <img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/recent-posts-grid.gif'; ?>"
                         alt="<?php echo esc_attr__( 'Grid 2', 'oildrop' ); ?>">
                </label>
            </p>

			<?php
		}
	}
endif;
add_filter( 'in_widget_form', 'oildrop_add_recent_posts_custom_options', 9, 3 );

if ( ! function_exists( 'oildrop_recent_posts_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function oildrop_recent_posts_setup() {
		if ( ! has_image_size( 'oildrop_top-news-3-2' ) ) {
			add_image_size( 'oildrop_top-news-3-2', 770, 513, true );
		}
	}
endif; // oildrop_recent_posts_setup
add_action( 'after_setup_theme', 'oildrop_recent_posts_setup', 20 );