jQuery('#fw-option-project-gallery').closest('.postbox').addClass('project-gallery-postbox');
