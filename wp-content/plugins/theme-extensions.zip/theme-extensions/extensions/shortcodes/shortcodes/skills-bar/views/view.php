<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
/**
 * @var $atts
 */

/* style="width:<?php echo esc_attr( $atts['level'] )?>%" */
$unique_id = uniqid();

?>

<!-- Skills Progress Bar -->
<section class="fw-skills-bar">
    <span class="progress-title"><?php echo esc_attr( $atts[ 'title' ] ); ?></span>
    <span class="progress-level"><?php echo esc_attr( $atts[ 'level' ] ); ?>%</span>
    <div class="progress">
        <div class="progress-bar progress-bar<?php echo esc_attr( $unique_id ); ?>" role="progressbar"
             data-unique-id="<?php echo esc_attr( $unique_id ); ?>"
             aria-valuenow="1" aria-valuemin="0" aria-valuemax="100"
             data-level="<?php echo esc_attr( $atts[ 'level' ] ); ?>">
        </div>
    </div>
</section>