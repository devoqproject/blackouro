<?php
/**
 * Beautiful Posts Banner widget class
 *
 * @since 3.0.0
 */
class oildrop_Banner_Strip_Widget extends WP_Widget {

    public function __construct() {
        $widget_ops = array( 'classname' => 'widget_banner_strip', 'description' => esc_html__('Add beautiful banners to your site.', 'oildrop') );
        parent::__construct( 'banner-strip', esc_html__('Banner Strip', 'oildrop'), $widget_ops );
        $this->alt_option_name = 'widget_banner_strip';
    }

    /**
     * @param array $args
     * @param array $instance
     */
    public function widget( $args, $instance ) {
        global $post;
        /** This filter is documented in wp-includes/default-widgets.php */
        $instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
        $url_1 = ( ! empty( $instance['url_1'] ) ) ? $instance['url_1'] : '';
        $image_1 = ( ! empty( $instance['image_1'] ) ) ? $instance['image_1'] : '';
        $url_2 = ( ! empty( $instance['url_2'] ) ) ? $instance['url_2'] : '';
        $image_2 = ( ! empty( $instance['image_2'] ) ) ? $instance['image_2'] : '';
        $url_3 = ( ! empty( $instance['url_3'] ) ) ? $instance['url_3'] : '';
        $image_3 = ( ! empty( $instance['image_3'] ) ) ? $instance['image_3'] : '';

        $posts_array = array();
        $images_array = array();
        if( $image_1 ) {
            $posts_array[] = $url_1;
            $images_array[] = $image_1;
        }
        if( $image_2 ) {
            $posts_array[] = $url_2;
            $images_array[] = $image_2;
        }
        if( $image_3 ) {
            $posts_array[] = $url_3;
            $images_array[] = $image_3;
        }
        $posts_num = count( $posts_array );

        echo wp_kses_post($args['before_widget']);

        if ( !empty($instance['title']) )
            {echo wp_kses_post($args['before_title'] . $instance['title'] . $args['after_title']);}
        ?>
        <div class="banner-strip__row row">
        <?php for( $i = 0; $i < $posts_num; $i++ ){
            switch( $posts_num ){
                case 3:
                    ?>
                    <div class="banner-strip__3 col-md-4">
                    <?php
                    break;
                case 2:
                    ?>
                    <div class="banner-strip__2 col-md-6">
                    <?php
                    break;
                default:
                    ?>
                    <div class="banner-strip__1 col-md-12"><?php
                    break;
            }?>
                <div class="banner-strip">
                    <div class="banner-strip__content">
                    <?php if( $posts_array[$i] != '') { ?>
						<a href="<?php echo esc_url( $posts_array[$i] ); ?>">
                    <?php } ?>
                            <img src="<?php echo esc_url( $images_array[$i] ); ?>" alt="#">
                    <?php if( $posts_array[$i] != '') { ?>
                        </a>
                    <?php } ?>
                    </div>
                </div>
            </div><?php
        }
        ?>
        </div>
        <?php
        echo wp_kses_post($args['after_widget']);
    }

    /**
     * @param array $new_instance
     * @param array $old_instance
     * 
*@return array
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['url_1'] = $new_instance['url_1'];
        $instance['image_1'] = $new_instance['image_1'];
        $instance['url_2'] = $new_instance['url_2'];
        $instance['image_2'] = $new_instance['image_2'];
        $instance['url_3'] = $new_instance['url_3'];
        $instance['image_3'] = $new_instance['image_3'];
        return $instance;
    }

    /**
     * @param array $instance
     */
    public function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $url_1 = isset( $instance['url_1'] ) ? $instance['url_1'] : '';
        $image_1 = isset( $instance['image_1'] ) ? $instance['image_1'] : '';
        $url_2 = isset( $instance['url_2'] ) ? $instance['url_2'] : '';
        $image_2 = isset( $instance['image_2'] ) ? $instance['image_2'] : '';
        $url_3 = isset( $instance['url_3'] ) ? $instance['url_3'] : '';
        $image_3 = isset( $instance['image_3'] ) ? $instance['image_3'] : '';

        ?>
        <div class="nav-menu-widget-form-controls">

            <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e( 'Title:', 'oildrop' ) ?></label>
                <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_attr( $title ); ?>"/>
            </p>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'url_1' ) ); ?>"><?php esc_html_e( '1st Post URL:', 'oildrop' ); ?></label>
                <input id="<?php echo esc_attr( $this->get_field_id( 'url_1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'url_1' ) ); ?>" type="url" value="<?php echo esc_url( $url_1 ); ?>" size="36" />
            </p>

			<p>
                <label for="<?php echo esc_attr($this->get_field_name( 'image_1' )); ?>"><?php esc_html_e( '1st Image URL:', 'oildrop' ); ?></label>
                <input class="upload_image_input" name="<?php echo esc_attr($this->get_field_name( 'image_1' )); ?>" id="<?php echo esc_attr($this->get_field_id( 'image_1' )); ?>" type="text" size="24"  value="<?php echo esc_url( $image_1 ); ?>" />
                <input class="upload_image_button button" type="button" value="<?php esc_attr_e( 'Set Image', 'oildrop' ); ?>" />
            </p>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'url_2' ) ); ?>"><?php esc_html_e( '2nd Post URL:', 'oildrop' ); ?></label>
                <input id="<?php echo esc_attr( $this->get_field_id( 'url_2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'url_2' ) ); ?>" type="url" value="<?php echo esc_url( $url_2 ); ?>" size="36" />
            </p>

			<p>
                <label for="<?php echo esc_attr($this->get_field_name( 'image_2' )); ?>"><?php esc_html_e( '2nd Image URL:', 'oildrop' ); ?></label>
                <input class="upload_image_input" name="<?php echo esc_attr($this->get_field_name( 'image_2' )); ?>" id="<?php echo esc_attr($this->get_field_id( 'image_2' )); ?>" type="text" size="24"  value="<?php echo esc_url( $image_2 ); ?>" />
                <input class="upload_image_button button" type="button" value="<?php esc_attr_e( 'Set Image', 'oildrop' ); ?>" />
            </p>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'url_3' ) ); ?>"><?php esc_html_e( '3rd Post URL:', 'oildrop' ); ?></label>
                <input id="<?php echo esc_attr( $this->get_field_id( 'url_3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'url_3' ) ); ?>" type="url" value="<?php echo esc_url( $url_3 ); ?>" size="36" />
            </p>

			<p>
                <label for="<?php echo esc_attr($this->get_field_name( 'image_3' )); ?>"><?php esc_html_e( '3rd Image URL:', 'oildrop' ); ?></label>
                <input class="upload_image_input" name="<?php echo esc_attr($this->get_field_name( 'image_3' )); ?>" id="<?php echo esc_attr($this->get_field_id( 'image_3' )); ?>" type="text" size="24"  value="<?php echo esc_url( $image_3 ); ?>" />
                <input class="upload_image_button button" type="button" value="<?php esc_attr_e( 'Set Image', 'oildrop' ); ?>" />
            </p>

        </div>
        <?php
    }
}

if (!function_exists( 'oildrop_register_widget_banner_strip')) :
    function oildrop_register_widget_banner_strip() {
        register_widget('oildrop_Banner_Strip_Widget');
    }
endif;
add_action('widgets_init', 'oildrop_register_widget_banner_strip');