<?php

if ( ! function_exists( 'oildrop_get_main_slider_category' ) ) :
	function oildrop_get_main_slider_category() {
		$category = array ( 'id' => 0, 'slug' => '', 'count' => 0, 'name' => '' );
		if ( is_admin() ) {
			$category[ 'id' ] = wp_create_category( 'Main Slider' );
		}

		if ( $cat = get_term_by( 'slug', 'main-slider', 'category' ) ) {
			$category[ 'id' ]    = $cat->term_id;
			$category[ 'count' ] = $cat->count;
			$category[ 'name' ]  = $cat->name;
			$category[ 'slug' ]  = 'main-slider';
		}

		return $category;
	}
endif;

if ( ! function_exists( 'oildrop_main_slider_active' ) ) :
	function oildrop_main_slider_active() {
		global $sidebars_widgets;
		if ( ! empty( $sidebars_widgets[ 'sidebar-before-header' ][ 0 ] ) ) {
			if ( preg_match( '/^oildrop-main-slider/', $sidebars_widgets[ 'sidebar-before-header' ][ 0 ] ) ) {
				return true;
			}
		}

		return false;
	}
endif;


if ( ! function_exists( 'oildrop_post_thumbnail' ) ) :
	/**
	 * Display an optional post thumbnail.
	 *
	 * Wraps the post thumbnail in an anchor element on index views, or a div
	 * element when on single views.
	 */
	function oildrop_post_thumbnail( $args = array () ) {
		global $post;
		extract( $args );
		$background      = isset( $background ) ? $background : false;
		$print           = isset( $print ) ? $print : true;
		$thumbnail_size  = isset( $thumbnail_size ) ? $thumbnail_size : 'post-thumbnail';
		$thumbnail_class = isset( $thumbnail_class ) ? $thumbnail_class : 'post-thumbnail';
		$read_more       = isset( $read_more ) ? $read_more : false;
		$use_default     = isset( $use_default ) ? $use_default : false;
		$no_url          = isset( $no_url ) ? $no_url : false;
		$only_url        = isset( $only_url ) ? $only_url : false;
		$is_widget       = isset( $is_widget ) ? $is_widget : false;
		$post_obj        = isset( $post_obj ) ? $post_obj : $post;

		if ( post_password_required( $post_obj ) || is_attachment() || ( ! has_post_thumbnail( $post_obj ) && ! $use_default ) ) {
			return;
		}

		$post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post_obj->ID ), $thumbnail_size );
		if ( empty( $post_thumbnail[ 0 ] ) && $use_default ) :
			$theme_options  = oildrop_get_theme_mods();
			$post_thumbnail = array ( esc_url( $theme_options[ 'default_thumbnail' ] ) );
		endif;

		$post_img = esc_url( $post_thumbnail[ 0 ] );

		if ( $only_url ) {
			return $post_img;
		}

		if ( $background ) :

			if ( ! empty( $post_img ) ) :
				if ( $print ) :
					echo "background: url('" . $post_img . "') 50% 50% no-repeat; background-size: cover;";
				else :
					return "background: url('" . $post_img . "') 50% 50% no-repeat; background-size: cover;";
				endif;
			endif;

		elseif ( ! $is_widget && is_singular() ) : ?>

			<div class="<?php echo esc_attr( $thumbnail_class ); ?>">
				<?php the_post_thumbnail(); ?>
			</div><!-- .post-thumbnail -->

		<?php else : ?>

			<?php
			if ( $print ) {
				if ( ! $no_url ) { ?>
					<a class="<?php echo esc_attr( $thumbnail_class ); ?>" href="<?php esc_url( the_permalink( $post_obj ) ); ?>" aria-hidden="true">
					<?php if ( $read_more ) { ?>
						<span class="post-thumbnail--link"><span><?php esc_html_e( 'Read More', 'oildrop' ); ?></span></span>
					<?php }
				}
				echo '<img class="' . esc_attr( $thumbnail_class ) . '" src="' . esc_url( $post_img ) . '" alt="' . esc_attr( get_the_title( $post_obj ) ) . '" />';
				if ( ! $no_url ) { ?>
					</a>
				<?php }
			} else {
				$output = '';
				if ( ! $no_url ) {
					$output .= '<a class="' . esc_attr( $thumbnail_class ) . '" href="' . esc_url( get_the_permalink( $post_obj ) ) . '" aria-hidden="true">';
					if ( $read_more ) {
						$output .= '<span class="post-thumbnail--link"><span>' . esc_html__( 'Read More', 'oildrop' ) . '</span></span>';
					}
				}
				$output .= '<img class="' . esc_attr( $thumbnail_class ) . '" src="' . esc_url( $post_img ) . '" alt="' . esc_attr( get_the_title( $post_obj ) ) . '" />';
				if ( ! $no_url ) {
					$output .= '</a>';
				}

				return $output;
			}
			?>


		<?php endif; // End is_singular()
	}
endif;


if ( ! function_exists( 'oildrop_get_theme_mods' ) ) :
	function oildrop_get_theme_mods() {

		$theme_mods = wp_parse_args(
			get_theme_mods(),
			array()
		);
		$theme_mods['default_thumbnail'] = '';
		return $theme_mods;

	}
endif;


if ( ! function_exists( 'oildrop_get_first_category' ) ) :
	function oildrop_get_first_category( $post_id, $class = '' ) {
		$categories_list = wp_get_post_categories( $post_id, array ( 'orderby' => 'slug', 'fields' => 'all' ) );
		$first_cat_id    = $categories_list[ 0 ]->term_id;
		$first_cat_name  = $categories_list[ 0 ]->name;
		$first_cat_link  = get_category_link( $first_cat_id );

		if ( $categories_list && oildrop_categorized_blog() ) {
			if ( ! empty( $class ) ) {
				$class = ' class="' . $class . '"';
			}
			$first_cat_name = '<a href="' . $first_cat_link . '"' . $class . '>' . $first_cat_name . '</a>';
		} else {
			$first_cat_name = '';
		}

		return $first_cat_name;
	}
endif;


if ( ! function_exists( 'oildrop_categorized_blog' ) ) :
	/**
	 * Determine whether blog/site has more than one category.
	 *
	 * @return bool True of there is more than one category, false otherwise.
	 */
	function oildrop_categorized_blog() {
		if ( false === ( $all_the_cool_cats = get_transient( 'oildrop_categories' ) ) ) {
			// Create an array of all the categories that are attached to posts.
			$all_the_cool_cats = get_categories( array (
				'fields'     => 'ids',
				'hide_empty' => 1,

				// We only need to know if there is more than one category.
				'number'     => 2,
			) );

			// Count the number of categories that are attached to the posts.
			$all_the_cool_cats = count( $all_the_cool_cats );

			set_transient( 'oildrop_categories', $all_the_cool_cats );
		}

		if ( $all_the_cool_cats > 1 ) {
			// This blog has more than 1 category so oildrop_categorized_blog should return true.
			return true;
		} else {
			// This blog has only 1 category so oildrop_categorized_blog should return false.
			return false;
		}
	}
endif;