<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['icon-set'] = 'theme-icons';
$cfg['has-icon'] = true;