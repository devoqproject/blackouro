jQuery(document).ready(function () {
    jQuery(".flickr_badge_image a").attr('target', '_blank');
    jQuery('.wrap-flickr ul div').wrap('<li></li>');
});