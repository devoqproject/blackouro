<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array (
	'page_builder' => array (
		'title'       => esc_html__( 'Icon Boxes in Row', 'oildrop' ),
		'description' => esc_html__( 'Several icon boxes in row', 'oildrop' ),
		'tab'         => esc_html__( 'Content Elements', 'oildrop' ),
	)
);